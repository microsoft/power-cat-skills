# MCP & Tooling catalog (14 items)

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> Skills tell the agent how; MCP servers give the agent live tools and data.

### Generate MCP App UI (`generate-mcp-app-ui`)

- **What it does:** Create interactive widgets for MCP tool output.
- **Purpose:** Author | **Tier:** skill | **Products:** Agent Skills, MCP & Tooling
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mcp-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use generate-mcp-app-ui: Create interactive widgets for MCP tool output."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mcp-apps/skills/generate-mcp-app-ui (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-92

### Generate Codeful MCP Tool (`generate-codeful-mcp-tool`)

- **What it does:** Generate a self-contained JavaScript MCP tool runtime and matching registration metadata.
- **Purpose:** Build | **Tier:** skill | **Products:** MCP & Tooling
- **Personas:** Developer or maker
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mcp-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Create a codeful MCP tool with JavaScript server logic and registration metadata."
- **Source:** https://github.com/microsoft/power-platform-skills/blob/474e614e1f4c0ec193a9ca01caf86b701c79bc26/plugins/mcp-apps/skills/generate-codeful-mcp-tool/SKILL.md (verified 21 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-143

### Power Platform Skills: setup & host guide (`pp-skills-setup-host`)

- **What it does:** How to install, run, secure and govern the skills across supported hosts.
- **Purpose:** Govern | **Tier:** reference | **Products:** MCP & Tooling
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Documentation / reference: read the source; nothing to install or run.
- **Install (verbatim from source):** `/plugin install power-platform-skills@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-137

### Author (`author`)

- **What it does:** Create and edit cloud flows.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** MCP & Tooling
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-130

### compile / sync (`compile / sync`)

- **What it does:** Validate YAML and synchronize app state.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** MCP & Tooling
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-platform-skills@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-129

### connect · Canvas (`connect`)

- **What it does:** Bind the agent to a live coauthoring session.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** MCP & Tooling
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-platform-skills@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-127

### connect · Dataverse (`connect`)

- **What it does:** Authenticate and register an environment server.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** MCP & Tooling
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-connect: Authenticate and register an environment server."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-connect/SKILL.md (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-133

### describe / list (`describe / list`)

- **What it does:** Discover controls, APIs, data sources, and schema.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** MCP & Tooling
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-platform-skills@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-128

### Diagnose (`diagnose`)

- **What it does:** Inspect actions, loops, expressions, and connections.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** MCP & Tooling
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-132

### host protocol (`host protocol`)

- **What it does:** Run widgets in MCP Apps-compatible hosts.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** MCP & Tooling
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-platform-skills@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-136

### Operate (`operate`)

- **What it does:** Publish, copy, route, and manage runs.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** MCP & Tooling
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-131

### query / data (`query / data`)

- **What it does:** Read and change Dataverse records.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** MCP & Tooling
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-overview/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-134

### Dataverse tool selection (`dv-tool-selection`)

- **What it does:** When to use MCP, the Dataverse CLI, the Python SDK or PAC for Dataverse work.
- **Purpose:** Operate | **Tier:** reference | **Products:** MCP & Tooling
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Documentation / reference: read the source; nothing to install or run.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-overview/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-135

### Model Context Protocol (`mcp-servers`)

- **What it does:** The open protocol that lets agents connect to live tools and data.
- **Purpose:** Reference | **Tier:** reference | **Products:** MCP & Tooling
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Model Context Protocol | **Licence:** Open protocol — see source
- **Marketplace:** Model Context Protocol
- **Where it runs:** Documentation / reference: read the source; nothing to install or run.
- **Install:** No verified install command. Point the user to the source link.
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://modelcontextprotocol.io/ (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-96
