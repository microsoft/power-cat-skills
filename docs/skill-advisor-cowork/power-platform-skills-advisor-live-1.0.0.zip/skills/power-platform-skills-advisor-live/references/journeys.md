# End-to-end journeys

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

## Build a production Canvas App

- **Audience:** Maker and app team
- **Outcome:** A connected, reviewed Canvas App ready for governed release.

| Step | Item | What happens |
|---|---|---|
| Discover | `canvas-app` | Confirm requirements and live metadata. |
| Build | `generate-canvas-app` | Generate screens and controls. |
| Connect | `add-data-source` | Connect approved data sources. |
| Validate | `compile_canvas` | Validate the generated YAML. |
| Review | `analyze-canvas-performance` | Audit delegation and performance. |

## Release a secure Power Pages site

- **Audience:** Web delivery team
- **Outcome:** A secure, tested site with independent review evidence.

| Step | Item | What happens |
|---|---|---|
| Plan | `plan-alm` | Set boundaries and deployment topology. |
| Build | `create-site` | Create the customer experience. |
| Secure | `setup-auth` | Configure identity and access. |
| Test | `test-site` | Inspect browser and network behavior. |
| Review | `PowerCAT OverPage` | Run the six-pillar assessment. |

## Build and assure a cloud flow

- **Audience:** Automation team
- **Outcome:** A working cloud flow with solution-wide review evidence.

| Step | Item | What happens |
|---|---|---|
| Route | `route-environments` | Select the correct environment. |
| Build | `build-flow` | Generate the complete flow. |
| Debug | `debug-flow` | Inspect failed runs. |
| Diagnose | `diagnose-flow` | Trace cross-action causes. |
| Review | `PowerCAT Overflow` | Review the exported solution. |

## Create a native Mobile App

- **Audience:** Mobile delivery team
- **Outcome:** A branded native experience with preview and debug evidence.

| Step | Item | What happens |
|---|---|---|
| Plan | `native-app-planner` | Gate data and device capabilities. |
| Design | `design-system` | Create branded design tokens. |
| Build | `create-mobile-app` | Generate screens in parallel. |
| Preview | `preview-screens` | Review screens without Metro. |
| Debug | `debug-app` | Validate navigation and runtime behavior. |

## Modernize an InfoPath solution

- **Audience:** Modernization team
- **Outcome:** A modern Canvas experience with reviewed performance.

| Step | Item | What happens |
|---|---|---|
| Assess | `analyze-canvas-performance` | Baseline the current app. |
| Plan | `infopath-to-canvas` | Define the migration path. |
| Transform | `canvas-app` | Coauthor the modern implementation. |
| Data | `migrate-to-dataverse` | Move data to the governed target. |
| Validate | `Canvas performance` | Compare the modern result. |

