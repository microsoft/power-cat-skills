# Power Pages catalog (23 items)

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> Read each delivery-system boundary horizontally from planning through deployment and operations.

### Add Cloud Flow (`add-cloud-flow`)

- **What it does:** Connect notifications or asynchronous processes.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-cloud-flow: Connect notifications or asynchronous processes."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/add-cloud-flow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-66

### Author Webpage Content (`author-webpage-content`)

- **What it does:** Compose the localized HTML body of an existing non-SPA webpage for edit-site; not a direct user command.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/author-webpage-content (verified 26 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-159

### Create Site (`create-site`)

- **What it does:** Create a modern Power Pages code site.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-site: Create a modern Power Pages code site."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/create-site (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-9

### Edit Site (`edit-site`)

- **What it does:** Plan and customize a downloaded non-SPA Power Pages site: pages, content, navigation, templates and styling.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use edit-site: Plan and customize a downloaded non-SPA Power Pages site: pages, content, navigation, templates and styling."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/edit-site (verified 26 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-157

### Integrate Backend (`integrate-backend`)

- **What it does:** Choose Web API, server logic, cloud flow, or a combination.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use integrate-backend: Choose Web API, server logic, cloud flow, or a combination."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/integrate-backend (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-65

### Integrate WebAPI (`integrate-webapi`)

- **What it does:** Create typed clients, services, permissions, and settings.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use integrate-webapi: Create typed clients, services, permissions, and settings."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/integrate-webapi (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-73

### Setup Datamodel (`setup-datamodel`)

- **What it does:** Design Dataverse tables and relationships.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages, Dataverse
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-datamodel: Design Dataverse tables and relationships."
- **Prerequisite:** siteType: "spa" — a generated SPA site identified by powerpages.config.json
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/setup-datamodel (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-72

### Deploy Site (`deploy-site`)

- **What it does:** Build and upload a Power Pages code site.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Cross-Cutting, Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use deploy-site: Build and upload a Power Pages code site."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/deploy-site (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-14

### Setup Pipeline (`setup-pipeline`)

- **What it does:** Configure Power Platform pipelines.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Pages, Cross-Cutting, Governance
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-pipeline: Configure Power Platform pipelines."
- **Prerequisite:** powerpages.config.json exists in the project root
- **Prerequisite:** .solution-manifest.json exists (solution must be created first via setup-solution)
- **Prerequisite:** Azure CLI logged in (az account show succeeds)
- **Prerequisite:** PAC CLI logged in (pac env who succeeds)
- **Prerequisite:** A Power Platform environment with Pipelines package installed (the "host" environment)
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/setup-pipeline (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-80

### Setup Solution (`setup-solution`)

- **What it does:** Create the solution and deployment boundary.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-solution: Create the solution and deployment boundary."
- **Prerequisite:** PAC CLI installed and authenticated (pac env who returns an environment URL)
- **Prerequisite:** Azure CLI installed and logged in (az account show succeeds)
- **Prerequisite:** powerpages.config.json exists in the project root (site must be deployed at least once so .powerpages-site/ exists with component records)
- **Prerequisite:** Confirm .powerpages-site/ folder exists (required to find component records)
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/setup-solution (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-76

### Create WebRoles (`create-webroles`)

- **What it does:** Create roles and access mapping.
- **Purpose:** Govern | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-webroles: Create roles and access mapping."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/create-webroles (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-78

### manage-headers / firewall (`manage-headers / firewall`)

- **What it does:** Strengthen browser and network controls.
- **Purpose:** Govern | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use manage-headers: Strengthen browser and network controls."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/manage-headers (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-67

### Plan ALM (`plan-alm`)

- **What it does:** Choose solution boundaries, pipelines, and deployment topology.
- **Purpose:** Govern | **Tier:** skill | **Products:** Cross-Cutting, Power Pages, Dataverse, Governance
- **Personas:** Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use plan-alm: Choose solution boundaries, pipelines, and deployment topology."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/plan-alm (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-2

### Setup Auth (`setup-auth`)

- **What it does:** Configure authentication and identity providers.
- **Purpose:** Govern | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-auth: Configure authentication and identity providers."
- **Access needed:** Azure AD admin consent: Open the API permissions tab -> Grant admin consent for {your tenant}.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/setup-auth (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-77

### Diagnose Deployment (`diagnose-deployment`)

- **What it does:** Interpret deployment failures and remediation.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use diagnose-deployment: Interpret deployment failures and remediation."
- **Prerequisite:** Project root with powerpages.config.json
- **Prerequisite:** PAC CLI installed (will report if missing)
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/diagnose-deployment (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-71

### HAR-assisted analysis (`HAR-assisted analysis`)

- **What it does:** Map network bottlenecks to site code and components.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overpage@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overpage: Map network bottlenecks to site code and components."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overpage/skills/powercat-overpage (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-70

### PowerCAT OverPage (`PowerCAT OverPage`)

- **What it does:** Six-pillar review: security, performance, accessibility, maintainability, architecture, and reliability.
- **Purpose:** Review | **Tier:** skill | **Products:** Cross-Cutting, Power Pages, Power CAT, Modernization
- **Personas:** QA lead, Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overpage@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overpage: Six-pillar review: security, performance, accessibility, maintainability, architecture, and reliability."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overpage/skills/powercat-overpage (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-12

### Analyze Performance (`analyze-performance`)

- **What it does:** Scan a non-SPA Power Pages site for performance anti-patterns and offer safe fixes with approval.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analyze-performance: Scan a non-SPA Power Pages site for performance anti-patterns and offer safe fixes with approval."
- **Prerequisite:** An existing local non-SPA Power Pages project or PAC CLI site download.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/analyze-performance (verified 26 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-158

### Audit Permissions (`audit-permissions`)

- **What it does:** Review table permissions and scopes.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages, Governance
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use audit-permissions: Review table permissions and scopes."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/audit-permissions (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-74

### Migrate WebAPI SelectAll (`migrate-webapi-selectall`)

- **What it does:** Replace deprecated Web API wildcard fields with least-privilege explicit columns.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/migrate-webapi-selectall (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-75

### Scan Code (`scan-code`)

- **What it does:** Inspect frontend code for issues before release.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use scan-code: Inspect frontend code for issues before release."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/scan-code (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-69

### Security Review (`security-review`)

- **What it does:** Run a security-focused site assessment.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages, Governance
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use security-review: Run a security-focused site assessment."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/security-review (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-79

### Test Site (`test-site`)

- **What it does:** Crawl pages in a real browser and inspect console/network failures.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages, Governance, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use test-site: Crawl pages in a real browser and inspect console/network failures."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/test-site (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-68
