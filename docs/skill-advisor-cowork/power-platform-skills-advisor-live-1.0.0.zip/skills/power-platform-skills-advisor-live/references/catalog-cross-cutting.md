# Cross-Cutting catalog (34 items)

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> Use cross-cutting skills for environments, ALM, connectors, administration, and communication.

### MCP Apps (`MCP Apps`)

- **What it does:** Visualize structured tool output in compatible hosts.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mcp-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use generate-mcp-app-ui: Visualize structured tool output in compatible hosts."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mcp-apps/skills/generate-mcp-app-ui (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-111

### Power CAT Storytelling (`Power CAT Storytelling`)

- **What it does:** Turn outcomes into a customer-ready story.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-adoption@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-adoption/skills/powercat-storytelling (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-113

### Skill Recorder (`Skill Recorder`)

- **What it does:** Desktop app: record a task, review the Copilot analysis, then generate a reusable Agent Skill or Automation.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Agent Skills, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Skill Recorder
- **Where it runs:** App: open from the source link.
- **Install (verbatim from source):** `/plugin install skill-recorder@skill-recorder` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/skill-recorder/blob/main/README.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-1

### Design Guide (`design-guide`)

- **What it does:** Establish brand tokens before generating a Code App.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT
- **Personas:** Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-code-apps@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use code-apps-design-guide: Establish brand tokens before generating a Code App."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-code-apps/skills/design-guide (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-3

### MCS Assistant (`mcs-assistant`)

- **What it does:** Experimental classic-to-modern Copilot Studio migration: Experimental plugin for creating, editing, validating, and migrating classic Copilot Studio agents to the new experience.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Agent Skills
- **Personas:** Developer or maker
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Documentation / reference: read the source; nothing to install or run.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/main/README.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-10

### Powercat PP Architecture Advisor (`powercat-pp-architecture-advisor`)

- **What it does:** Design a composed Power Platform solution through adaptive discovery and architecture review.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Power CAT
- **Personas:** QA lead, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-architecture-advisor@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-architecture-advisor/skills/powercat-pp-architecture-advisor (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-106

### add-connector · Connectors (`add-connector`)

- **What it does:** Use the generic connector fallback safely.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-connector: Use the generic connector fallback safely."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/add-connector (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-110

### Create Code App (`create-code-app`)

- **What it does:** Scaffold React/Vite apps with connector-first data access.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-code-app: Scaffold React/Vite apps with connector-first data access."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/create-code-app (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-7

### Create Site (`create-site`)

- **What it does:** Create a modern Power Pages code site.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-site: Create a modern Power Pages code site."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/create-site (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-9

### Dv Metadata (`dv-metadata`)

- **What it does:** Design tables, columns, relationships, forms, and views.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Dataverse, Modernization
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-metadata: Design tables, columns, relationships, forms, and views."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-metadata/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-6

### Genpage (`genpage`)

- **What it does:** Plan a model-driven generative page and its Dataverse shape.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use genpage: Plan a model-driven generative page and its Dataverse shape."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/model-apps/skills/genpage (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-5

### deploy · Apps (`deploy`)

- **What it does:** Push Code Apps or Mobile Apps through product tooling.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Cross-Cutting, Power Apps
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use deploy: Push Code Apps or Mobile Apps through product tooling."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/deploy (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-15

### Deploy Site (`deploy-site`)

- **What it does:** Build and upload a Power Pages code site.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Cross-Cutting, Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use deploy-site: Build and upload a Power Pages code site."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/deploy-site (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-14

### Dv Solution (`dv-solution`)

- **What it does:** Create, export, import, promote, and validate solutions.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Cross-Cutting, Dataverse, Governance
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-solution: Create, export, import, promote, and validate solutions."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-solution/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-16

### Setup Pipeline (`setup-pipeline`)

- **What it does:** Configure Power Platform pipelines.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Pages, Cross-Cutting, Governance
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-pipeline: Configure Power Platform pipelines."
- **Prerequisite:** powerpages.config.json exists in the project root
- **Prerequisite:** .solution-manifest.json exists (solution must be created first via setup-solution)
- **Prerequisite:** Azure CLI logged in (az account show succeeds)
- **Prerequisite:** PAC CLI logged in (pac env who succeeds)
- **Prerequisite:** A Power Platform environment with Pipelines package installed (the "host" environment)
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/setup-pipeline (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-80

### Create PP Dev Env (`create-pp-dev-env`)

- **What it does:** Provision developer environments with standard governance defaults.
- **Purpose:** Govern | **Tier:** skill | **Products:** Cross-Cutting, Power CAT
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-governance@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-governance/skills/create-pp-dev-env (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-107

### Dev Environment Deprecation Report (`dev-environment-deprecation-report`)

- **What it does:** Report which unmanaged developer environments will be suspended, the apps, flows and agents at risk, and makers over the limit.
- **Purpose:** Govern | **Tier:** skill | **Products:** Cross-Cutting, Power CAT
- **Personas:** Admin
- **Status:** Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-governance@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dev-environment-deprecation-report: Report which unmanaged developer environments will be suspended, the apps, flows and agents at risk, and makers over the limit."
- **Access needed:** Power Platform admin: A user without Power Platform admin rights — the admin connectors will return nothing useful
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-governance/skills/dev-environment-deprecation-report (verified 26 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-161

### Plan ALM (`plan-alm`)

- **What it does:** Choose solution boundaries, pipelines, and deployment topology.
- **Purpose:** Govern | **Tier:** skill | **Products:** Cross-Cutting, Power Pages, Dataverse, Governance
- **Personas:** Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use plan-alm: Choose solution boundaries, pipelines, and deployment topology."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/plan-alm (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-2

### Build Flow (`build-flow`)

- **What it does:** Generate a complete cloud flow through FlowAgent.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Cross-Cutting, Power Automate
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use build-flow: Generate a complete cloud flow through FlowAgent."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/build-flow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-8

### Canvas App (`canvas-app`)

- **What it does:** Plan and coauthor Canvas Apps through the live authoring service.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Cross-Cutting, Power Apps, Modernization
- **Personas:** Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/canvas-apps/skills/canvas-app (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-4

### Diagnose Flow (`diagnose-flow`)

- **What it does:** Diagnose failed runs, loops, connections, and expressions.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Cross-Cutting, Power Automate
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use diagnose-flow: Diagnose failed runs, loops, connections, and expressions."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/diagnose-flow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-17

### Route Environments (`route-environments`)

- **What it does:** Resolve the correct environment before any lifecycle action.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate, Cross-Cutting
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use route-environments: Resolve the correct environment before any lifecycle action."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/route-environments (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-63

### Copilot Studio migrate (`Copilot Studio migrate`)

- **What it does:** Experimental classic-to-modern Copilot Studio migration: Create a reviewed modern-orchestration copy of a classic agent.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Cross-Cutting
- **Personas:** QA lead
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/main/commands/migrate.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-22

### InfoPath To Canvas (`infopath-to-canvas`)

- **What it does:** Convert InfoPath forms into modern Canvas Apps.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install Power%20Platform%20Migration%20Factory@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use infopath-to-canvas: Convert InfoPath forms into modern Canvas Apps."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/Power%20Platform%20Migration%20Factory/infopath-to-canvas (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-20

### Migrate To Dataverse (`migrate-to-dataverse`)

- **What it does:** Move SharePoint-backed Canvas Apps toward Dataverse.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install Power%20Platform%20Migration%20Factory@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use migrate-to-dataverse: Move SharePoint-backed Canvas Apps toward Dataverse."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/Power%20Platform%20Migration%20Factory/migrate-to-dataverse (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-21

### Admin Digest (`Admin Digest`)

- **What it does:** Prioritize Message Center, health, issues, and deprecations.
- **Purpose:** Operate | **Tier:** skill | **Products:** Cross-Cutting, Power Automate, Governance, Modernization
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-admin-digest@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-admin-digest/skills/powercat-admin-digest (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-19

### Power CAT Admin Digest (`Power CAT Admin Digest`)

- **What it does:** Curate health, issues, messages, and deprecations.
- **Purpose:** Operate | **Tier:** skill | **Products:** Cross-Cutting, Power CAT
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-admin-digest@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-admin-digest/skills/powercat-admin-digest (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-112

### Dv Admin (`dv-admin`)

- **What it does:** Retention, archival, settings, audit, recycle bin, and bulk delete.
- **Purpose:** Operate | **Tier:** skill | **Products:** Dataverse, Cross-Cutting, Governance
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-admin: Retention, archival, settings, audit, recycle bin, and bulk delete."
- **Prerequisite:** PAC CLI latest .NET Framework build — pac data bulk-delete/pac data retention are only in the .NET Framework build (not the dotnet tool version). Check pac help; if it shows .NET 10/.NET 8, run pac install latest && pac use latest.
- **Prerequisite:** Authenticated (pac auth create), active profile (pac auth list), and System Administrator privilege on the target environment.
- **Prerequisite:** Headless hosts: SDK handles most settings (they are organization records); service principal for PAC-only ones. See dv-connect/references/headless-hosts.md.
- **Access needed:** Dataverse role: Authenticated (pac auth create), active profile (pac auth list), and System Administrator privilege on the target environment.
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-admin/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-89

### dv-admin + dv-security (`dv-admin + dv-security`)

- **What it does:** Maintain settings, retention, audit, roles, users, and access.
- **Purpose:** Operate | **Tier:** skill | **Products:** Cross-Cutting
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-admin: Maintain settings, retention, audit, roles, users, and access."
- **Prerequisite:** PAC CLI latest .NET Framework build — pac data bulk-delete/pac data retention are only in the .NET Framework build (not the dotnet tool version). Check pac help; if it shows .NET 10/.NET 8, run pac install latest && pac use latest.
- **Prerequisite:** Authenticated (pac auth create), active profile (pac auth list), and System Administrator privilege on the target environment.
- **Prerequisite:** Headless hosts: SDK handles most settings (they are organization records); service principal for PAC-only ones. See dv-connect/references/headless-hosts.md.
- **Access needed:** Admin + Dataverse role: (combines dv-admin + dv-security; System Administrator privilege / Global\|PP\|D365 Admin)
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-admin/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-18

### List Connections (`list-connections`)

- **What it does:** Discover connection identifiers and availability.
- **Purpose:** Operate | **Tier:** skill | **Products:** Cross-Cutting
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use list-connections: Discover connection identifiers and availability."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/list-connections (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-109

### PowerCAT OverPage (`PowerCAT OverPage`)

- **What it does:** Six-pillar review: security, performance, accessibility, maintainability, architecture, and reliability.
- **Purpose:** Review | **Tier:** skill | **Products:** Cross-Cutting, Power Pages, Power CAT, Modernization
- **Personas:** QA lead, Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overpage@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overpage: Six-pillar review: security, performance, accessibility, maintainability, architecture, and reliability."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overpage/skills/powercat-overpage (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-12

### PowerCAT Overflow (`PowerCAT Overflow`)

- **What it does:** Review every cloud flow in a solution against coding guidance.
- **Purpose:** Review | **Tier:** skill | **Products:** Cross-Cutting, Power Automate, Power CAT
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overflow@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overflow: Review every cloud flow in a solution against coding guidance."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overflow/skills/powercat-overflow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-11

### Pro-Code Eval (`Pro-Code Eval`)

- **What it does:** Generate feature, unit, and security evals for Code Apps and GenPages.
- **Purpose:** Review | **Tier:** skill | **Products:** Cross-Cutting, Governance
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-procode-eval@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-procode-eval (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-13

### Power Platform Well-Architected (`pp-well-architected`)

- **What it does:** Microsoft Learn guidance for evaluating solution design across the five pillars.
- **Purpose:** Review | **Tier:** reference | **Products:** Cross-Cutting
- **Personas:** QA lead, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** Microsoft Learn (CC BY 4.0)
- **Marketplace:** Microsoft Learn
- **Where it runs:** Documentation / reference: read the source; nothing to install or run.
- **Install:** No verified install command. Point the user to the source link.
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://learn.microsoft.com/en-us/power-platform/well-architected/ (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-105
