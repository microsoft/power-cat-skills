# Dataverse catalog (13 items)

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> Read each Dataverse boundary horizontally without mixing schema, records, release, or administration.

### Dataverse WebAPI Query (`dataverse-webapi-query`)

- **What it does:** Author OData and FetchXML across apps, flows, and APIs.
- **Purpose:** Author | **Tier:** skill | **Products:** Dataverse, Power CAT
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-dataverse@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-dataverse/skills/dataverse-webapi-query (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-82

### Dv Overview (`dv-overview`)

- **What it does:** Load foundational context, safety rules, and tool-capability guidance; specialist skills self-route by intent.
- **Purpose:** Author | **Tier:** skill | **Products:** Dataverse
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-overview: Load foundational context, safety rules, and tool-capability guidance; specialist skills self-route by intent."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-overview/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-81

### Add Sample Data (`add-sample-data`)

- **What it does:** Generate contextual sample records for app development.
- **Purpose:** Build | **Tier:** skill | **Products:** Dataverse, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-sample-data: Generate contextual sample records for app development."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/add-sample-data (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-86

### Dv Metadata (`dv-metadata`)

- **What it does:** Design tables, columns, relationships, forms, and views.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Dataverse, Modernization
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-metadata: Design tables, columns, relationships, forms, and views."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-metadata/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-6

### Setup Datamodel (`setup-datamodel`)

- **What it does:** Design Dataverse tables and relationships.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages, Dataverse
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-datamodel: Design Dataverse tables and relationships."
- **Prerequisite:** siteType: "spa" — a generated SPA site identified by powerpages.config.json
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/setup-datamodel (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-72

### Dv Solution (`dv-solution`)

- **What it does:** Create, export, import, promote, and validate solutions.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Cross-Cutting, Dataverse, Governance
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-solution: Create, export, import, promote, and validate solutions."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-solution/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-16

### ERP X++ (`erp-xpp`)

- **What it does:** Scaffold, build, package, deploy, synchronize, and verify Finance and Operations X++ customizations.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Dataverse
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use erp-xpp: Scaffold, build, package, deploy, synchronize, and verify Finance and Operations X++ customizations."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/erp-xpp/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-87

### Dv Security (`dv-security`)

- **What it does:** Roles, users, application users, business units, and access.
- **Purpose:** Govern | **Tier:** skill | **Products:** Dataverse, Governance, Modernization
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-security: Roles, users, application users, business units, and access."
- **Prerequisite:** PAC CLI installed and authenticated (pac auth create)
- **Prerequisite:** System Administrator role in target environment (or Global/PP/D365 Admin for self-elevate)
- **Prerequisite:** Active auth profile: pac auth list
- **Prerequisite:** Headless / restricted-egress hosts: SDK handles role / user / business-unit ops; service principal for PAC-only ops; verify egress with python scripts/auth.py --check. See dv-connect/references/headless-hosts.md.
- **Access needed:** Admin: Requires Global Admin, Power Platform Admin, or Dynamics 365 Admin
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-security/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-88

### Plan ALM (`plan-alm`)

- **What it does:** Choose solution boundaries, pipelines, and deployment topology.
- **Purpose:** Govern | **Tier:** skill | **Products:** Cross-Cutting, Power Pages, Dataverse, Governance
- **Personas:** Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use plan-alm: Choose solution boundaries, pipelines, and deployment topology."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/plan-alm (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-2

### Dv Connect (`dv-connect`)

- **What it does:** Install tools, authenticate, and register the Dataverse MCP server.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Dataverse
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-connect: Install tools, authenticate, and register the Dataverse MCP server."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-connect/SKILL.md (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-83

### Dv Query (`dv-query`)

- **What it does:** Read, filter, page, aggregate, and load records into pandas.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Dataverse
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-query: Read, filter, page, aggregate, and load records into pandas."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-query/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-84

### Dv Admin (`dv-admin`)

- **What it does:** Retention, archival, settings, audit, recycle bin, and bulk delete.
- **Purpose:** Operate | **Tier:** skill | **Products:** Dataverse, Cross-Cutting, Governance
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-admin: Retention, archival, settings, audit, recycle bin, and bulk delete."
- **Prerequisite:** PAC CLI latest .NET Framework build — pac data bulk-delete/pac data retention are only in the .NET Framework build (not the dotnet tool version). Check pac help; if it shows .NET 10/.NET 8, run pac install latest && pac use latest.
- **Prerequisite:** Authenticated (pac auth create), active profile (pac auth list), and System Administrator privilege on the target environment.
- **Prerequisite:** Headless hosts: SDK handles most settings (they are organization records); service principal for PAC-only ones. See dv-connect/references/headless-hosts.md.
- **Access needed:** Dataverse role: Authenticated (pac auth create), active profile (pac auth list), and System Administrator privilege on the target environment.
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-admin/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-89

### Dv Data (`dv-data`)

- **What it does:** CRUD, CSV import, multi-table loads, upsert, and sample data.
- **Purpose:** Operate | **Tier:** skill | **Products:** Dataverse, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-data: CRUD, CSV import, multi-table loads, upsert, and sample data."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-data/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-85
