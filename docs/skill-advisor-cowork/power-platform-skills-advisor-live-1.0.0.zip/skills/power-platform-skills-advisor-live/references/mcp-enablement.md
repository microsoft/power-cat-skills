# MCP server enablement

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

## dataverse

- **Model:** Tenant admin · PPAC toggle
- **Who:** Power Platform admin
- **Prerequisites:** Power Platform administrator role; Managed Environment required to govern via Advanced connector policies. Copilot Studio client is on by default; other clients must be enabled.
- **Server URL:** `https://{dataverseOrgName}.crm.dynamics.com/api/mcp`
- **Steps:**
  1. Power Platform admin center → Manage → Environments → select the environment → Settings.
  2. Settings → Product → Features → Dataverse Model Context Protocol → turn on “Allow MCP clients to interact with Dataverse MCP server”.
  3. For non-default clients (VS Code GitHub Copilot, Copilot CLI, Claude): Advanced Settings → open the client record → set Is Enabled = Yes → Save & Close.
  4. Connect your client to the server URL https://{org}.crm.dynamics.com/api/mcp.
- **Docs:** [Configure the Dataverse MCP server (Microsoft Learn)](https://learn.microsoft.com/en-us/power-apps/maker/data-platform/data-platform-mcp-disable)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#mcp-tooling--dataverse--enable

## canvas

- **Model:** Maker · plugin + Studio coauthoring
- **Who:** Maker / developer (no tenant admin)
- **Prerequisites:** .NET SDK 10.0+; a coding agent that supports MCP; an existing saved canvas app with Coauthoring enabled (Power Apps Studio → Settings → Updates → Coauthoring).
- **Install:** `{'command': '/plugin install canvas-apps@power-platform-skills', 'note': 'Requires /plugin marketplace add microsoft/power-platform-skills first.'}`
- **Steps:**
  1. Install the plugin: /plugin marketplace add microsoft/power-platform-skills then /plugin install canvas-apps@power-platform-skills (VS Code: Extensions → @agentPlugins canvas apps → Canvas Apps by Microsoft).
  2. Open the canvas app in Power Apps Studio with Coauthoring on; keep the browser tab open; copy the Studio URL.
  3. Run /configure-canvas-mcp, paste the Studio URL, sign in — it auto-extracts environment, app and cluster IDs.
  4. Verify: ask the agent “List the available Canvas App controls.”
- **Docs:** [Create & edit canvas apps with AI code tools (Microsoft Learn)](https://learn.microsoft.com/en-us/power-apps/maker/canvas-apps/create-canvas-external-tools)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#mcp-tooling--canvas--enable

## flowagent

- **Model:** Local · plugin + az login (offline)
- **Who:** Maker / developer (no tenant admin)
- **Prerequisites:** Node.js 18+ and Azure CLI (az login). Runs offline — no npm install, no npx, no remote host; ships a self-contained MCP engine (server/mcp.mjs).
- **Install:** `{'command': '/plugin install power-automate@power-platform-skills', 'note': "Registered in .mcp.json as 'flowagent'; needs only Node.js 18+ and az login."}`
- **Steps:**
  1. Install the plugin (GitHub Copilot CLI or Claude Code): /plugin marketplace add microsoft/power-platform-skills then /plugin install power-automate@power-platform-skills.
  2. Authenticate with Azure CLI: az login (MSAL is used for connection endpoints).
  3. Run the setup skill for first-time prerequisite setup.
  4. Use the skills: browse-flows, create-flow / build-flow, debug-flow / diagnose-flow, manage-flows, manage-desktop-flows.
- **Docs:** [Power Automate plugin — FlowAgent MCP (GitHub README)](https://github.com/microsoft/power-platform-skills/blob/main/plugins/power-automate/README.md)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#mcp-tooling--flowagent--enable

