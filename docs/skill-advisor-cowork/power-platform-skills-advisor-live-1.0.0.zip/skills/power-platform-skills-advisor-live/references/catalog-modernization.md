# Modernization catalog (21 items)

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> Read each legacy boundary horizontally through assessment, transformation, validation, and adoption.

### Power CAT Storytelling (`Power CAT Storytelling`)

- **What it does:** Turn outcomes into a customer-ready story.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-adoption@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-adoption/skills/powercat-storytelling (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-113

### Skill Recorder (`Skill Recorder`)

- **What it does:** Desktop app: record a task, review the Copilot analysis, then generate a reusable Agent Skill or Automation.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Agent Skills, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Skill Recorder
- **Where it runs:** App: open from the source link.
- **Install (verbatim from source):** `/plugin install skill-recorder@skill-recorder` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/skill-recorder/blob/main/README.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-1

### mcs-assistant architect (`mcs-assistant architect`)

- **What it does:** Experimental classic-to-modern Copilot Studio migration: Supporting architect agent that turns an approved behavior description and initialized target into modern orchestration YAML.
- **Purpose:** Author | **Tier:** skill | **Products:** Modernization
- **Personas:** Architect
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Agent Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/main/agents/copilot-studio-architect.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-124

### Add Sample Data (`add-sample-data`)

- **What it does:** Generate contextual sample records for app development.
- **Purpose:** Build | **Tier:** skill | **Products:** Dataverse, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-sample-data: Generate contextual sample records for app development."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/add-sample-data (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-86

### Dv Metadata (`dv-metadata`)

- **What it does:** Design tables, columns, relationships, forms, and views.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Dataverse, Modernization
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-metadata: Design tables, columns, relationships, forms, and views."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-metadata/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-6

### Dv Security (`dv-security`)

- **What it does:** Roles, users, application users, business units, and access.
- **Purpose:** Govern | **Tier:** skill | **Products:** Dataverse, Governance, Modernization
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-security: Roles, users, application users, business units, and access."
- **Prerequisite:** PAC CLI installed and authenticated (pac auth create)
- **Prerequisite:** System Administrator role in target environment (or Global/PP/D365 Admin for self-elevate)
- **Prerequisite:** Active auth profile: pac auth list
- **Prerequisite:** Headless / restricted-egress hosts: SDK handles role / user / business-unit ops; service principal for PAC-only ops; verify egress with python scripts/auth.py --check. See dv-connect/references/headless-hosts.md.
- **Access needed:** Admin: Requires Global Admin, Power Platform Admin, or Dynamics 365 Admin
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-security/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-88

### Canvas App (`canvas-app`)

- **What it does:** Plan and coauthor Canvas Apps through the live authoring service.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Cross-Cutting, Power Apps, Modernization
- **Personas:** Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/canvas-apps/skills/canvas-app (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-4

### Copilot migration plan (`Copilot migration plan`)

- **What it does:** Experimental classic-to-modern Copilot Studio migration: Approve capability and action-migration decisions.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Modernization
- **Personas:** Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Documentation / reference: read the source; nothing to install or run.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/main/commands/migrate.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-123

### Airtable To Power Platform (`airtable-to-power-platform`)

- **What it does:** Assess, transform, and migrate Airtable schema and data to Dataverse or SharePoint, with optional app generation.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install Power%20Platform%20Migration%20Factory@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/Power%20Platform%20Migration%20Factory/Airtable%20to%20Power%20Platform%20Migration (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-121

### InfoPath To Canvas (`infopath-to-canvas`)

- **What it does:** Convert InfoPath forms into modern Canvas Apps.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install Power%20Platform%20Migration%20Factory@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use infopath-to-canvas: Convert InfoPath forms into modern Canvas Apps."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/Power%20Platform%20Migration%20Factory/infopath-to-canvas (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-20

### Migrate Bootstrap (`migrate-bootstrap`)

- **What it does:** Migrate a traditional Power Pages site from Bootstrap 3 to Bootstrap 5 with a restore point, reviewed residual fixes, upload, and validation.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use migrate-bootstrap: Migrate a traditional Power Pages site from Bootstrap 3 to Bootstrap 5 with a restore point, reviewed residual fixes, upload, and validation."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/migrate-bootstrap (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-126

### Migrate To Dataverse (`migrate-to-dataverse`)

- **What it does:** Move SharePoint-backed Canvas Apps toward Dataverse.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install Power%20Platform%20Migration%20Factory@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use migrate-to-dataverse: Move SharePoint-backed Canvas Apps toward Dataverse."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/Power%20Platform%20Migration%20Factory/migrate-to-dataverse (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-21

### PowerCAT Access Migration (`powercat-accessmigration`)

- **What it does:** Migrate an Access .mdb or .accdb database to Dataverse, with an optional model-driven app and approval before writes.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Modernization, Power CAT
- **Personas:** Developer or maker
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-cat-skills@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Migrate my Access database to Dataverse with an optional model-driven app."
- **Source:** https://github.com/microsoft/power-cat-skills/blob/c6c836259e7459bba01305e1d8bf2b9cdbb221e4/Power%20Platform%20Migration%20Factory/Access%20to%20Dataverse%20Migration/SKILL.md (verified 21 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-145

### Admin Digest (`Admin Digest`)

- **What it does:** Prioritize Message Center, health, issues, and deprecations.
- **Purpose:** Operate | **Tier:** skill | **Products:** Cross-Cutting, Power Automate, Governance, Modernization
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-admin-digest@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-admin-digest/skills/powercat-admin-digest (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-19

### Dv Data (`dv-data`)

- **What it does:** CRUD, CSV import, multi-table loads, upsert, and sample data.
- **Purpose:** Operate | **Tier:** skill | **Products:** Dataverse, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-data: CRUD, CSV import, multi-table loads, upsert, and sample data."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-data/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-85

### Canvas performance (`Canvas performance`)

- **What it does:** Delegation and performance audit.
- **Purpose:** Review | **Tier:** skill | **Products:** Governance, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-canvas-apps@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analyze-canvas-performance: Delegation and performance audit."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-canvas-apps/skills/analyze-canvas-performance (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-119

### Copilot Studio chat (`Copilot Studio chat`)

- **What it does:** Experimental classic-to-modern Copilot Studio migration: Test the published modern agent.
- **Purpose:** Review | **Tier:** skill | **Products:** Modernization
- **Personas:** QA lead
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/main/commands/chat.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-125

### Copilot Studio describe (`Copilot Studio describe`)

- **What it does:** Experimental classic-to-modern Copilot Studio migration: Read-only supporting agent that inventories classic agent behavior, topics, actions, knowledge, and uncertainties.
- **Purpose:** Review | **Tier:** skill | **Products:** Modernization
- **Personas:** QA lead
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/main/agents/copilot-studio-describer.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-122

### PowerCAT OverPage (`PowerCAT OverPage`)

- **What it does:** Six-pillar review: security, performance, accessibility, maintainability, architecture, and reliability.
- **Purpose:** Review | **Tier:** skill | **Products:** Cross-Cutting, Power Pages, Power CAT, Modernization
- **Personas:** QA lead, Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overpage@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overpage: Six-pillar review: security, performance, accessibility, maintainability, architecture, and reliability."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overpage/skills/powercat-overpage (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-12

### Analyze Canvas Performance (`analyze-canvas-performance`)

- **What it does:** Audit delegation, performance, and best practices.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps, Power CAT, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-canvas-apps@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analyze-canvas-performance: Audit delegation, performance, and best practices."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-canvas-apps/skills/analyze-canvas-performance (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-26

### Test Site (`test-site`)

- **What it does:** Crawl pages in a real browser and inspect console/network failures.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages, Governance, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use test-site: Crawl pages in a real browser and inspect console/network failures."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/test-site (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-68
