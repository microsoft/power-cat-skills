# Governance catalog (16 items)

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> A release is ready when architecture, access, tests, deployment, and operations all have evidence.

### deploy · Governance (`deploy`)

- **What it does:** Push product artifacts.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Governance
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use deploy: Push product artifacts."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/deploy (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-120

### Dv Solution (`dv-solution`)

- **What it does:** Create, export, import, promote, and validate solutions.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Cross-Cutting, Dataverse, Governance
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-solution: Create, export, import, promote, and validate solutions."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-solution/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-16

### Setup Pipeline (`setup-pipeline`)

- **What it does:** Configure Power Platform pipelines.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Pages, Cross-Cutting, Governance
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-pipeline: Configure Power Platform pipelines."
- **Prerequisite:** powerpages.config.json exists in the project root
- **Prerequisite:** .solution-manifest.json exists (solution must be created first via setup-solution)
- **Prerequisite:** Azure CLI logged in (az account show succeeds)
- **Prerequisite:** PAC CLI logged in (pac env who succeeds)
- **Prerequisite:** A Power Platform environment with Pipelines package installed (the "host" environment)
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/setup-pipeline (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-80

### Dv Security (`dv-security`)

- **What it does:** Roles, users, application users, business units, and access.
- **Purpose:** Govern | **Tier:** skill | **Products:** Dataverse, Governance, Modernization
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-security: Roles, users, application users, business units, and access."
- **Prerequisite:** PAC CLI installed and authenticated (pac auth create)
- **Prerequisite:** System Administrator role in target environment (or Global/PP/D365 Admin for self-elevate)
- **Prerequisite:** Active auth profile: pac auth list
- **Prerequisite:** Headless / restricted-egress hosts: SDK handles role / user / business-unit ops; service principal for PAC-only ops; verify egress with python scripts/auth.py --check. See dv-connect/references/headless-hosts.md.
- **Access needed:** Admin: Requires Global Admin, Power Platform Admin, or Dynamics 365 Admin
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-security/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-88

### Plan ALM (`plan-alm`)

- **What it does:** Choose solution boundaries, pipelines, and deployment topology.
- **Purpose:** Govern | **Tier:** skill | **Products:** Cross-Cutting, Power Pages, Dataverse, Governance
- **Personas:** Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use plan-alm: Choose solution boundaries, pipelines, and deployment topology."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/plan-alm (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-2

### Admin Digest (`Admin Digest`)

- **What it does:** Prioritize Message Center, health, issues, and deprecations.
- **Purpose:** Operate | **Tier:** skill | **Products:** Cross-Cutting, Power Automate, Governance, Modernization
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-admin-digest@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-admin-digest/skills/powercat-admin-digest (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-19

### Dv Admin (`dv-admin`)

- **What it does:** Retention, archival, settings, audit, recycle bin, and bulk delete.
- **Purpose:** Operate | **Tier:** skill | **Products:** Dataverse, Cross-Cutting, Governance
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-admin: Retention, archival, settings, audit, recycle bin, and bulk delete."
- **Prerequisite:** PAC CLI latest .NET Framework build — pac data bulk-delete/pac data retention are only in the .NET Framework build (not the dotnet tool version). Check pac help; if it shows .NET 10/.NET 8, run pac install latest && pac use latest.
- **Prerequisite:** Authenticated (pac auth create), active profile (pac auth list), and System Administrator privilege on the target environment.
- **Prerequisite:** Headless hosts: SDK handles most settings (they are organization records); service principal for PAC-only ones. See dv-connect/references/headless-hosts.md.
- **Access needed:** Dataverse role: Authenticated (pac auth create), active profile (pac auth list), and System Administrator privilege on the target environment.
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-admin/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-89

### Manage Flows (`manage-flows`)

- **What it does:** Publish, disable, copy, inventory, test, and batch operations.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Automate, Governance
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use manage-flows: Publish, disable, copy, inventory, test, and batch operations."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/manage-flows (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-59

### Canvas performance (`Canvas performance`)

- **What it does:** Delegation and performance audit.
- **Purpose:** Review | **Tier:** skill | **Products:** Governance, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-canvas-apps@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analyze-canvas-performance: Delegation and performance audit."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-canvas-apps/skills/analyze-canvas-performance (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-119

### OverPage (`OverPage`)

- **What it does:** Six-pillar Power Pages review.
- **Purpose:** Review | **Tier:** skill | **Products:** Governance
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overpage@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overpage: Six-pillar Power Pages review."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overpage/skills/powercat-overpage (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-118

### Overflow (`Overflow`)

- **What it does:** Solution-wide cloud-flow review.
- **Purpose:** Review | **Tier:** skill | **Products:** Governance
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overflow@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overflow: Solution-wide cloud-flow review."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overflow/skills/powercat-overflow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-117

### Pro-Code Eval (`Pro-Code Eval`)

- **What it does:** Generate feature, unit, and security evals for Code Apps and GenPages.
- **Purpose:** Review | **Tier:** skill | **Products:** Cross-Cutting, Governance
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-procode-eval@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-procode-eval (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-13

### Audit Permissions (`audit-permissions`)

- **What it does:** Review table permissions and scopes.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages, Governance
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use audit-permissions: Review table permissions and scopes."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/audit-permissions (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-74

### debug-app / diagnose-flow (`debug-app / diagnose-flow`)

- **What it does:** Investigate runtime failures.
- **Purpose:** Review | **Tier:** skill | **Products:** Governance
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-116

### Security Review (`security-review`)

- **What it does:** Run a security-focused site assessment.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages, Governance
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use security-review: Run a security-focused site assessment."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/security-review (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-79

### Test Site (`test-site`)

- **What it does:** Crawl pages in a real browser and inspect console/network failures.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages, Governance, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use test-site: Crawl pages in a real browser and inspect console/network failures."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/test-site (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-68
