# Persona index

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

Persona is an editorial tag. Treat it as a ranking hint, never as a filter that hides a good match.

## Developer or maker (62)

| Item | Purpose | Products | Status |
|---|---|---|---|
| `MCP Apps` | Author | Cross-Cutting | GA |
| `Power CAT Storytelling` | Author | Cross-Cutting, Modernization | GA |
| `add-cloud-flow` | Build | Power Pages | GA |
| `add-connector` | Build | Power Apps | Preview |
| `add-connector` | Build | Cross-Cutting | GA |
| `add-data-source` | Mcp | Power Apps | GA |
| `add-datasource` | Build | Power Apps | GA |
| `add-knowledge` | Author | Agent Skills | Preview |
| `add-sample-data` | Build | Dataverse, Modernization | GA |
| `agent-skills-standard` | Author | Agent Skills | GA |
| `airtable-to-power-platform` | Migrate | Modernization | GA |
| `app-builder` | Build | Power Apps | Preview |
| `author` | Mcp | MCP & Tooling | GA |
| `author-webpage-content` | Build | Power Pages | GA |
| `build-android-binary` | Build | Power Apps | GA |
| `build-flow` | Mcp | Cross-Cutting, Power Automate | GA |
| `build-ios-binary` | Build | Power Apps | GA |
| `clone-agent` | Build | Agent Skills | Preview |
| `connect` | Mcp | MCP & Tooling | GA |
| `create-agent` | Author | Agent Skills | Preview |
| `create-code-app` | Build | Cross-Cutting, Power Apps | GA |
| `create-mobile-app` | Build | Power Apps | Preview |
| `create-site` | Build | Cross-Cutting, Power Pages | GA |
| `dataverse-webapi-query` | Author | Dataverse, Power CAT | GA |
| `delete-agent` | Operate | Agent Skills | Preview |
| `describe / list` | Mcp | MCP & Tooling | GA |
| `dv-connect` | Mcp | Dataverse | GA |
| `dv-data` | Operate | Dataverse, Modernization | GA |
| `dv-metadata` | Build | Cross-Cutting, Power Apps, Dataverse, Modernization | GA |
| `dv-overview` | Author | Dataverse | GA |
| `dv-query` | Mcp | Dataverse | GA |
| `dv-tool-selection` | Operate | MCP & Tooling | GA |
| `edit-app` | Build | Power Apps | Preview |
| `edit-site` | Build | Power Pages | GA |
| `generate-canvas-app` | Build | Power Apps | GA |
| `generate-codeful-mcp-tool` | Build | MCP & Tooling | Unspecified |
| `generate-mcp-app-ui` | Author | Agent Skills, MCP & Tooling | GA |
| `generate-native-extension` | Build | Power Apps | GA |
| `generate-pcf-companion` | Build | Power Apps | GA |
| `generate-ppmplugin` | Build | Power Apps | GA |
| `generate-ppmplugin-manifest` | Build | Power Apps | GA |
| `genpage` | Build | Cross-Cutting, Power Apps | GA |
| `host protocol` | Mcp | MCP & Tooling | GA |
| `infopath-to-canvas` | Migrate | Cross-Cutting, Power Apps, Power CAT, Modernization | GA |
| `integrate-backend` | Build | Power Pages | GA |
| `integrate-webapi` | Build | Power Pages | GA |
| `loop-my-prompt` | Author | Power CAT | Unspecified |
| `manage-desktop-flows` | Mcp | Power Automate | GA |
| `mcp-servers` | Reference | MCP & Tooling | GA |
| `mcs-assistant` | Author | Cross-Cutting, Agent Skills | Preview |
| `migrate-to-dataverse` | Migrate | Cross-Cutting, Power Apps, Power CAT, Modernization | GA |
| `native-app-planner` | Build | Power Apps | Preview |
| `operate` | Mcp | MCP & Tooling | GA |
| `pcf` | Build | Power Apps | Preview |
| `powercat-accessmigration` | Migrate | Modernization, Power CAT | Unspecified |
| `powercat-storytelling` | Author | Power CAT | GA |
| `pull-agent` | Build | Agent Skills | Preview |
| `query / data` | Mcp | MCP & Tooling | GA |
| `report-issue` | Operate | Power Apps | Preview |
| `resubmit / cancel` | Operate | Power Automate | GA |
| `setup-app-insights` | Operate | Power Apps | Preview |
| `setup-datamodel` | Build | Power Pages, Dataverse | GA |

## Architect (15)

| Item | Purpose | Products | Status |
|---|---|---|---|
| `Copilot migration plan` | Migrate | Modernization | GA |
| `PowerCAT OverPage` | Review | Cross-Cutting, Power Pages, Power CAT, Modernization | GA |
| `canvas-app` | Mcp | Cross-Cutting, Power Apps, Modernization | GA |
| `design-guide` | Author | Cross-Cutting, Power Apps, Power CAT | GA |
| `design-native-extension-feature` | Author | Power Apps | GA |
| `design-system` | Author | Power Apps | Preview |
| `dv-metadata` | Build | Cross-Cutting, Power Apps, Dataverse, Modernization | GA |
| `edit-app` | Build | Power Apps | Preview |
| `edit-site` | Build | Power Pages | GA |
| `genpage` | Build | Cross-Cutting, Power Apps | GA |
| `mcs-assistant architect` | Author | Modernization | Preview |
| `plan-alm` | Govern | Cross-Cutting, Power Pages, Dataverse, Governance | GA |
| `powercat-pp-architecture-advisor` | Author | Cross-Cutting, Power CAT | GA |
| `pp-well-architected` | Review | Cross-Cutting | GA |
| `setup-datamodel` | Build | Power Pages, Dataverse | GA |

## Admin (45)

| Item | Purpose | Products | Status |
|---|---|---|---|
| `Admin Digest` | Operate | Cross-Cutting, Power Automate, Governance, Modernization | GA |
| `Power CAT Admin Digest` | Operate | Cross-Cutting, Power CAT | GA |
| `PowerCAT OverPage` | Review | Cross-Cutting, Power Pages, Power CAT, Modernization | GA |
| `Pro-Code Eval` | Review | Cross-Cutting, Governance | GA |
| `add-skill` | Deploy | Agent Skills | Preview |
| `assemble-ppmplugin` | Deploy | Power Apps | GA |
| `audit-permissions` | Review | Power Pages, Governance | GA |
| `browse-flows` | Mcp | Power Automate | GA |
| `compile_canvas` | Mcp | Power Apps | GA |
| `connect` | Mcp | MCP & Tooling | GA |
| `connection lifecycle` | Mcp | Power Automate | GA |
| `create-flow` | Mcp | Power Automate | GA |
| `create-pp-dev-env` | Govern | Cross-Cutting, Power CAT | GA |
| `create-webroles` | Govern | Power Pages | GA |
| `deploy` | Deploy | Cross-Cutting, Power Apps | GA |
| `deploy` | Deploy | Governance | GA |
| `deploy + Wrap` | Deploy | Power Apps | Preview |
| `deploy-site` | Deploy | Cross-Cutting, Power Pages | GA |
| `dev-environment-deprecation-report` | Govern | Cross-Cutting, Power CAT | Preview |
| `diagnose` | Mcp | MCP & Tooling | GA |
| `diagnose-deployment` | Operate | Power Pages | GA |
| `diagnose-flow` | Mcp | Cross-Cutting, Power Automate | GA |
| `dv-admin` | Operate | Dataverse, Cross-Cutting, Governance | GA |
| `dv-admin + dv-security` | Operate | Cross-Cutting | GA |
| `dv-security` | Govern | Dataverse, Governance, Modernization | GA |
| `dv-solution` | Deploy | Cross-Cutting, Dataverse, Governance | GA |
| `erp-xpp` | Deploy | Dataverse | GA |
| `eval-generator-code-app` | Review | Power Apps, Power CAT | GA |
| `eval-generator-gen-pages` | Review | Power Apps, Power CAT | GA |
| `genpage-upload.js` | Deploy | Power Apps | GA |
| `integrate-webapi` | Build | Power Pages | GA |
| `list-connections` | Operate | Cross-Cutting | GA |
| `manage-headers / firewall` | Govern | Power Pages | GA |
| `pcf` | Build | Power Apps | Preview |
| `plan-alm` | Govern | Cross-Cutting, Power Pages, Dataverse, Governance | GA |
| `pp-skills-setup-host` | Govern | MCP & Tooling | GA |
| `publish-agent` | Deploy | Agent Skills | Preview |
| `publish-pcf-companion` | Deploy | Power Apps | GA |
| `push-agent` | Deploy | Agent Skills | Preview |
| `route-environments` | Mcp | Power Automate, Cross-Cutting | GA |
| `security-review` | Review | Power Pages, Governance | GA |
| `setup` | Mcp | Power Automate | GA |
| `setup-auth` | Govern | Power Pages | GA |
| `setup-pipeline` | Deploy | Power Pages, Cross-Cutting, Governance | GA |
| `setup-solution` | Deploy | Power Pages | GA |

## QA lead (43)

| Item | Purpose | Products | Status |
|---|---|---|---|
| `Canvas performance` | Review | Governance, Modernization | GA |
| `Copilot Studio chat` | Review | Modernization | Preview |
| `Copilot Studio describe` | Review | Modernization | Preview |
| `Copilot Studio migrate` | Migrate | Cross-Cutting | Preview |
| `Findings viewer` | Review | Power Automate | GA |
| `HAR-assisted analysis` | Review | Power Pages | GA |
| `OverPage` | Review | Governance | GA |
| `Overflow` | Review | Governance | GA |
| `PowerCAT OverPage` | Review | Cross-Cutting, Power Pages, Power CAT, Modernization | GA |
| `PowerCAT Overflow` | Review | Cross-Cutting, Power Automate, Power CAT | GA |
| `Pro-Code Eval` | Review | Cross-Cutting, Governance | GA |
| `Skill Recorder` | Author | Cross-Cutting, Agent Skills, Modernization | GA |
| `analyze-canvas-performance` | Review | Power Apps, Power CAT, Modernization | GA |
| `analyze-performance` | Review | Power Pages | GA |
| `app-builder` | Build | Power Apps | Preview |
| `audit-permissions` | Review | Power Pages, Governance | GA |
| `audit-ppmplugin` | Review | Power Apps | GA |
| `check-updates` | Operate | Power Apps | Preview |
| `compile / sync` | Mcp | MCP & Tooling | GA |
| `compile_canvas` | Mcp | Power Apps | GA |
| `debug-app` | Review | Power Apps | Preview |
| `debug-app / diagnose-flow` | Review | Governance | GA |
| `debug-extension` | Review | Power Apps | GA |
| `debug-flow` | Mcp | Power Automate | GA |
| `dv-solution` | Deploy | Cross-Cutting, Dataverse, Governance | GA |
| `eval-generator-code-app` | Review | Power Apps, Power CAT | GA |
| `eval-generator-gen-pages` | Review | Power Apps, Power CAT | GA |
| `expression help` | Mcp | Power Automate | GA |
| `generate-ppmplugin-manifest` | Build | Power Apps | GA |
| `manage-flows` | Operate | Power Automate, Governance | GA |
| `migrate-bootstrap` | Migrate | Modernization | GA |
| `migrate-webapi-selectall` | Review | Power Pages | GA |
| `pcf` | Build | Power Apps | Preview |
| `powercat-pp-architecture-advisor` | Author | Cross-Cutting, Power CAT | GA |
| `pp-well-architected` | Review | Cross-Cutting | GA |
| `preview-screens` | Review | Power Apps | Preview |
| `scan-code` | Review | Power Pages | GA |
| `security-review` | Review | Power Pages, Governance | GA |
| `telemetry` | Operate | Power Apps | Preview |
| `telemetry` | Operate | Power Apps | Preview |
| `telemetry` | Operate | Power Apps | GA |
| `test-native-extension` | Review | Power Apps | GA |
| `test-site` | Review | Power Pages, Governance, Modernization | GA |

