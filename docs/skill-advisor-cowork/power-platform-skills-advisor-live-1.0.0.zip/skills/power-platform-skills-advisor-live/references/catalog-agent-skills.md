# Agent Skills catalog (12 items)

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> Most pure SKILL.md procedures travel; paths, tools, plugins, permissions, and MCP wiring may not.

### Skill Recorder (`Skill Recorder`)

- **What it does:** Desktop app: record a task, review the Copilot analysis, then generate a reusable Agent Skill or Automation.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Agent Skills, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Skill Recorder
- **Where it runs:** App: open from the source link.
- **Install (verbatim from source):** `/plugin install skill-recorder@skill-recorder` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/skill-recorder/blob/main/README.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-1

### Add Knowledge (`add-knowledge`)

- **What it does:** Add a public website, SharePoint, OneDrive or uploaded-file knowledge source to a locally cloned Copilot Studio agent by writing knowledge YAML; push and publish are separate.
- **Purpose:** Author | **Tier:** skill | **Products:** Agent Skills
- **Personas:** Developer or maker
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Add our public product documentation website as a knowledge source to my cloned Copilot Studio agent."
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/4014ae689d1228d86cb3aaab938b1e66f8e2e10d/skills/add-knowledge/SKILL.md (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-147

### Agent Skills open standard (`agent-skills-standard`)

- **What it does:** The open authoring format for skills: SKILL.md structure, packaging, and portability.
- **Purpose:** Author | **Tier:** reference | **Products:** Agent Skills
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Agent Skills (open standard) | **Licence:** Open standard — see source
- **Marketplace:** Agent Skills
- **Where it runs:** Documentation / reference: read the source; nothing to install or run.
- **Install:** No verified install command. Point the user to the source link.
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://agentskills.io/home (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-90

### Create Agent (`create-agent`)

- **What it does:** Create a new Copilot Studio agent and PAC-connected local workspace, optionally adding instructions, skills, tools, knowledge and settings; it never publishes.
- **Purpose:** Author | **Tier:** skill | **Products:** Agent Skills
- **Personas:** Developer or maker
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Create a new Copilot Studio agent that answers HR policy questions."
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/4014ae689d1228d86cb3aaab938b1e66f8e2e10d/skills/create-agent/SKILL.md (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-149

### Generate MCP App UI (`generate-mcp-app-ui`)

- **What it does:** Create interactive widgets for MCP tool output.
- **Purpose:** Author | **Tier:** skill | **Products:** Agent Skills, MCP & Tooling
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mcp-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use generate-mcp-app-ui: Create interactive widgets for MCP tool output."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mcp-apps/skills/generate-mcp-app-ui (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-92

### MCS Assistant (`mcs-assistant`)

- **What it does:** Experimental classic-to-modern Copilot Studio migration: Experimental plugin for creating, editing, validating, and migrating classic Copilot Studio agents to the new experience.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Agent Skills
- **Personas:** Developer or maker
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Documentation / reference: read the source; nothing to install or run.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/main/README.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-10

### Clone Agent (`clone-agent`)

- **What it does:** Clone an existing Copilot Studio agent into a new local PAC CLI workspace; it reads the cloud agent and writes local files only.
- **Purpose:** Build | **Tier:** skill | **Products:** Agent Skills
- **Personas:** Developer or maker
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Clone my Copilot Studio agent into a local folder so I can edit it."
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/4014ae689d1228d86cb3aaab938b1e66f8e2e10d/skills/clone-agent/SKILL.md (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-148

### Pull Agent (`pull-agent`)

- **What it does:** Pull remote Copilot Studio agent changes into an existing PAC CLI workspace, merging into local files; it never pushes or publishes.
- **Purpose:** Build | **Tier:** skill | **Products:** Agent Skills
- **Personas:** Developer or maker
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Pull the latest remote changes into my local Copilot Studio agent workspace."
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/4014ae689d1228d86cb3aaab938b1e66f8e2e10d/skills/pull-agent/SKILL.md (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-152

### Add Skill (`add-skill`)

- **What it does:** Acquire an existing skill from a local file or CAT gallery and optionally import it into a Copilot Studio CLI-agent workspace. Publishing is separate.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Agent Skills
- **Personas:** Admin
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Add an existing agent skill from my local files or the CAT gallery to my Copilot Studio workspace."
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/4014ae689d1228d86cb3aaab938b1e66f8e2e10d/skills/add-skill/SKILL.md (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-146

### Publish Agent (`publish-agent`)

- **What it does:** Publish an existing Copilot Studio agent, making its current cloud draft live for users who can access it; it does not upload, pull or push.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Agent Skills
- **Personas:** Admin
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Publish my Copilot Studio agent so its current draft goes live."
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/4014ae689d1228d86cb3aaab938b1e66f8e2e10d/skills/publish-agent/SKILL.md (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-151

### Push Agent (`push-agent`)

- **What it does:** Push local changes from a PAC CLI workspace to the Copilot Studio agent's cloud draft, pulling first; it never publishes.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Agent Skills
- **Personas:** Admin
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Push my local Copilot Studio agent changes to the cloud draft without publishing."
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/4014ae689d1228d86cb3aaab938b1e66f8e2e10d/skills/push-agent/SKILL.md (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-153

### Delete Agent (`delete-agent`)

- **What it does:** DESTRUCTIVE: permanently delete a Copilot Studio agent from the cloud after an exact typed confirmation. Irreversible; local workspace files are not deleted.
- **Purpose:** Operate | **Tier:** skill | **Products:** Agent Skills
- **Personas:** Developer or maker
- **Status:** Experimental (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Copilot Studio Plugin
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install copilot-studio-plugin@copilot-studio-plugin` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Permanently delete the Copilot Studio agent <agent name> from my environment."
- **Source:** https://github.com/microsoft/copilot-studio-plugin/blob/4014ae689d1228d86cb3aaab938b1e66f8e2e10d/skills/delete-agent/SKILL.md (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-150
