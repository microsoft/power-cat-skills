# Power Automate catalog (15 items)

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> Read each automation scope horizontally from discovery and build through review and operations.

### Browse Flows (`browse-flows`)

- **What it does:** Browse environments, flows, connections, and runs.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use browse-flows: Browse environments, flows, connections, and runs."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/browse-flows (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-55

### Build Flow (`build-flow`)

- **What it does:** Generate a complete cloud flow through FlowAgent.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Cross-Cutting, Power Automate
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use build-flow: Generate a complete cloud flow through FlowAgent."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/build-flow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-8

### connection lifecycle (`connection lifecycle`)

- **What it does:** Discover, share, fix, and map connections.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-64

### Create Flow (`create-flow`)

- **What it does:** Guided creation with explicit choices and connection mapping.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-flow: Guided creation with explicit choices and connection mapping."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/create-flow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-56

### Debug Flow (`debug-flow`)

- **What it does:** Interactively inspect a failed run and its actions.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use debug-flow: Interactively inspect a failed run and its actions."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/debug-flow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-61

### Diagnose Flow (`diagnose-flow`)

- **What it does:** Diagnose failed runs, loops, connections, and expressions.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Cross-Cutting, Power Automate
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use diagnose-flow: Diagnose failed runs, loops, connections, and expressions."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/diagnose-flow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-17

### expression help (`expression help`)

- **What it does:** Validate Workflow Definition Language expressions.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-57

### Manage Desktop Flows (`manage-desktop-flows`)

- **What it does:** List and run desktop-flow assets.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use manage-desktop-flows: List and run desktop-flow assets."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/manage-desktop-flows (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-60

### Route Environments (`route-environments`)

- **What it does:** Resolve the correct environment before any lifecycle action.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate, Cross-Cutting
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use route-environments: Resolve the correct environment before any lifecycle action."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/route-environments (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-63

### Setup (`setup`)

- **What it does:** Verify Node, Azure CLI login, environment, and FlowAgent MCP.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup: Verify Node, Azure CLI login, environment, and FlowAgent MCP."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/setup (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-54

### Admin Digest (`Admin Digest`)

- **What it does:** Prioritize Message Center, health, issues, and deprecations.
- **Purpose:** Operate | **Tier:** skill | **Products:** Cross-Cutting, Power Automate, Governance, Modernization
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-admin-digest@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-admin-digest/skills/powercat-admin-digest (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-19

### Manage Flows (`manage-flows`)

- **What it does:** Publish, disable, copy, inventory, test, and batch operations.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Automate, Governance
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use manage-flows: Publish, disable, copy, inventory, test, and batch operations."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/manage-flows (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-59

### resubmit / cancel (`resubmit / cancel`)

- **What it does:** Control problematic or recoverable runs.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Automate
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-62

### Findings viewer (`Findings viewer`)

- **What it does:** Prioritize findings by pillar, flow, and remediation.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overflow@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overflow: Prioritize findings by pillar, flow, and remediation."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overflow/skills/powercat-overflow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-58

### PowerCAT Overflow (`PowerCAT Overflow`)

- **What it does:** Review every cloud flow in a solution against coding guidance.
- **Purpose:** Review | **Tier:** skill | **Products:** Cross-Cutting, Power Automate, Power CAT
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overflow@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overflow: Review every cloud flow in a solution against coding guidance."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overflow/skills/powercat-overflow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-11
