# Power Apps catalog (44 items)

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> Read each app surface horizontally from plan and build through review and release.

### Design Guide (`design-guide`)

- **What it does:** Establish brand tokens before generating a Code App.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT
- **Personas:** Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-code-apps@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use code-apps-design-guide: Establish brand tokens before generating a Code App."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-code-apps/skills/design-guide (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-3

### Design Native Extension Feature (`design-native-extension-feature`)

- **What it does:** Create and approve the product requirements and cross-platform technical design.
- **Purpose:** Author | **Tier:** skill | **Products:** Power Apps
- **Personas:** Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use design-native-extension-feature: Create and approve the product requirements and cross-platform technical design."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/design-native-extension-feature (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-37

### Design System (`design-system`)

- **What it does:** Choose a visual direction and generate branded design tokens.
- **Purpose:** Author | **Tier:** skill | **Products:** Power Apps
- **Personas:** Architect
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use design-system: Choose a visual direction and generate branded design tokens."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/design-system (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-28

### add-connector · Mobile (`add-connector`)

- **What it does:** Add Power Platform connectors and generated services.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-connector: Add Power Platform connectors and generated services."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-connector (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-30

### Add Datasource (`add-datasource`)

- **What it does:** Connect Dataverse, SharePoint, Teams, Excel, or other services.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-datasource: Connect Dataverse, SharePoint, Teams, Excel, or other services."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/add-datasource (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-49

### App Builder (`app-builder`)

- **What it does:** Build or edit a complete model-driven app from a reviewable App Spec.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, QA lead
- **Status:** Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use app-builder: Build or edit a complete model-driven app from a reviewable App Spec."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/model-apps/skills/app-builder (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-51

### Build Android Binary (`build-android-binary`)

- **What it does:** Compile the Android Kotlin module into a runtime-loadable DEX.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use build-android-binary: Compile the Android Kotlin module into a runtime-loadable DEX."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/build-android-binary (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-40

### Build iOS Binary (`build-ios-binary`)

- **What it does:** Compile the iOS module into the flat device-slice framework required by Wrap.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use build-ios-binary: Compile the iOS module into the flat device-slice framework required by Wrap."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/build-ios-binary (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-41

### Create Code App (`create-code-app`)

- **What it does:** Scaffold React/Vite apps with connector-first data access.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-code-app: Scaffold React/Vite apps with connector-first data access."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/create-code-app (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-7

### Create Mobile App (`create-mobile-app`)

- **What it does:** Generate Expo/React Native screens in parallel.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-mobile-app: Generate Expo/React Native screens in parallel."
- **Access needed:** Azure AD admin consent: ...tenant-wide admin consent (Wrap native registration).
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/create-mobile-app (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-29

### Dv Metadata (`dv-metadata`)

- **What it does:** Design tables, columns, relationships, forms, and views.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Dataverse, Modernization
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-metadata: Design tables, columns, relationships, forms, and views."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-metadata/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-6

### Edit App (`edit-app`)

- **What it does:** Apply safe plan deltas; add offline scope when required.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use edit-app: Apply safe plan deltas; add offline scope when required."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/edit-app (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-34

### Generate Canvas App (`generate-canvas-app`)

- **What it does:** Generate PA YAML screens and controls.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/canvas-apps (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-23

### Generate Native Extension (`generate-native-extension`)

- **What it does:** Generate the Android and iOS native sources plus their manifest dispatch contract.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use generate-native-extension: Generate the Android and iOS native sources plus their manifest dispatch contract."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/generate-native-extension (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-38

### Generate PCF Companion (`generate-pcf-companion`)

- **What it does:** Generate the dispatcher PCF that connects Canvas Apps to the native module.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use generate-pcf-companion: Generate the dispatcher PCF that connects Canvas Apps to the native module."
- **Prerequisite:** The dispatcher PCF is deployed to your environment: run /publish-pcf-companion (handles publisher prefix selection, version bump, env confirmation, and the actual push).
- **Prerequisite:** A wrap build that has the .ppmplugin bundle loaded (the DEX/framework + manifest.json whose <name>/<receiver> this PCF dispatches to) — see /test-native-extension for the load recipe.
- **Prerequisite:** pac auth list shows your test environment as active.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/generate-pcf-companion (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-43

### Generate PPMPlugin (`generate-ppmplugin`)

- **What it does:** Build and verify the native .ppmplugin bundle end to end.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use generate-ppmplugin: Build and verify the native .ppmplugin bundle end to end."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/generate-ppmplugin (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-42

### Generate PPMPlugin Manifest (`generate-ppmplugin-manifest`)

- **What it does:** Validate, reconcile, and stage the .ppmplugin manifest for the selected platforms.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use generate-ppmplugin-manifest: Validate, reconcile, and stage the .ppmplugin manifest for the selected platforms."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/generate-ppmplugin-manifest (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-39

### Genpage (`genpage`)

- **What it does:** Plan a model-driven generative page and its Dataverse shape.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use genpage: Plan a model-driven generative page and its Dataverse shape."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/model-apps/skills/genpage (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-5

### Native App Planner (`native-app-planner`)

- **What it does:** Gate data, native capabilities, connectors, and screens.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/mobile-apps/agents/native-app-planner.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-27

### PCF Code Components (`pcf`)

- **What it does:** Build, test, deploy and verify Power Apps component framework (PCF) code components from Microsoft templates.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, QA lead, Admin
- **Status:** Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install pcf@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use pcf: Build, test, deploy and verify Power Apps component framework (PCF) code components from Microsoft templates."
- **Access needed:** Power Platform admin (canvas only): For canvas targets after a successful push, ... guide an admin through Power Apps component framework for canvas apps and the user through Studio import/setup.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/pcf/skills/pcf (verified 20 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-154

### Assemble PPMPlugin (`assemble-ppmplugin`)

- **What it does:** Reconcile staged binaries, assemble the final bundle, and verify its archive layout.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use assemble-ppmplugin: Reconcile staged binaries, assemble the final bundle, and verify its archive layout."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/assemble-ppmplugin (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-47

### deploy · Apps (`deploy`)

- **What it does:** Push Code Apps or Mobile Apps through product tooling.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Cross-Cutting, Power Apps
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use deploy: Push Code Apps or Mobile Apps through product tooling."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/deploy (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-15

### deploy + Wrap (`deploy + Wrap`)

- **What it does:** Build, push, and prepare distribution through Power Apps Wrap.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use deploy: Build, push, and prepare distribution through Power Apps Wrap."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/deploy (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-33

### genpage-upload.js (`genpage-upload.js`)

- **What it does:** Upload the generated page to its target app through the bundled SDK.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use genpage: Upload the generated page to its target app through the bundled SDK."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/model-apps/skills/genpage (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-53

### Publish PCF Companion (`publish-pcf-companion`)

- **What it does:** Build and publish the dispatcher PCF to the selected Power Platform environment.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use publish-pcf-companion: Build and publish the dispatcher PCF to the selected Power Platform environment."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/publish-pcf-companion (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-48

### Add Data Source (`add-data-source`)

- **What it does:** Discover connectors and live data-source schemas.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/canvas-apps/skills/add-data-source (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-24

### Canvas App (`canvas-app`)

- **What it does:** Plan and coauthor Canvas Apps through the live authoring service.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Cross-Cutting, Power Apps, Modernization
- **Personas:** Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/canvas-apps/skills/canvas-app (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-4

### compile_canvas (`compile_canvas`)

- **What it does:** Validate Canvas YAML before deployment.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Apps
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/canvas-apps (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-25

### InfoPath To Canvas (`infopath-to-canvas`)

- **What it does:** Convert InfoPath forms into modern Canvas Apps.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install Power%20Platform%20Migration%20Factory@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use infopath-to-canvas: Convert InfoPath forms into modern Canvas Apps."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/Power%20Platform%20Migration%20Factory/infopath-to-canvas (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-20

### Migrate To Dataverse (`migrate-to-dataverse`)

- **What it does:** Move SharePoint-backed Canvas Apps toward Dataverse.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install Power%20Platform%20Migration%20Factory@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use migrate-to-dataverse: Move SharePoint-backed Canvas Apps toward Dataverse."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/Power%20Platform%20Migration%20Factory/migrate-to-dataverse (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-21

### Check Updates (`check-updates`)

- **What it does:** Check the plugin, native host, Microsoft packages, and direct npm dependencies with per-package approval and rollback.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use check-updates: Check the plugin, native host, Microsoft packages, and direct npm dependencies with per-package approval and rollback."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/check-updates (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-35

### Report Issue · PCF (`report-issue`)

- **What it does:** File a bug report for the PCF plugin in its GitHub repository.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install pcf@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use report-issue: File a bug report for the PCF plugin in its GitHub repository."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/pcf/skills/report-issue (verified 20 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-155

### Set Up Application Insights (`setup-app-insights`)

- **What it does:** Configure optional observability for a Power Apps mobile app using an existing, customer-owned Application Insights resource. Off by default; no resource creation.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Enable Application Insights for this app"
- **Source:** https://github.com/microsoft/power-platform-skills/blob/474e614e1f4c0ec193a9ca01caf86b701c79bc26/plugins/mobile-apps/skills/setup-app-insights/SKILL.md (verified 21 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-144

### Telemetry (`telemetry`)

- **What it does:** Enable, disable, or check the mobile-app plugin's usage-data telemetry.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/telemetry (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-36

### Telemetry · PCF (`telemetry`)

- **What it does:** Enable, disable, or check the PCF plugin's usage-data telemetry.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install pcf@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use telemetry: Enable, disable, or check the PCF plugin's usage-data telemetry."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/pcf/skills/telemetry (verified 20 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-156

### Telemetry · Mobile Extension (`telemetry`)

- **What it does:** Enable, disable, or check usage telemetry transmission for the Power Apps Mobile Extension plugin.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use telemetry: Enable, disable, or check usage telemetry transmission for the Power Apps Mobile Extension plugin."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/telemetry (verified 26 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-160

### Analyze Canvas Performance (`analyze-canvas-performance`)

- **What it does:** Audit delegation, performance, and best practices.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps, Power CAT, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-canvas-apps@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analyze-canvas-performance: Audit delegation, performance, and best practices."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-canvas-apps/skills/analyze-canvas-performance (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-26

### Audit PPMPlugin (`audit-ppmplugin`)

- **What it does:** Statically audit a built bundle and route findings to the owning stage.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use audit-ppmplugin: Statically audit a built bundle and route findings to the owning stage."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/audit-ppmplugin (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-45

### Debug App (`debug-app`)

- **What it does:** Check routes, payloads, contrast, icons, and runtime issues.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use debug-app: Check routes, payloads, contrast, icons, and runtime issues."
- **Access needed:** tenant admin (conditional): The fix requires a tenant admin action (e.g., AAD consent).
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/debug-app (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-32

### Debug Extension (`debug-extension`)

- **What it does:** Diagnose failures and apply approved fixes across native, manifest, and PCF contracts.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use debug-extension: Diagnose failures and apply approved fixes across native, manifest, and PCF contracts."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/debug-extension (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-46

### Eval Generator Code App (`eval-generator-code-app`)

- **What it does:** Generate feature, unit, and security evals plus dashboard.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps, Power CAT
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-procode-eval@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use eval-generator-code-app: Generate feature, unit, and security evals plus dashboard."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-procode-eval/skills/eval-generator-code-app (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-50

### Eval Generator Gen Pages (`eval-generator-gen-pages`)

- **What it does:** Generate presence, unit, and security checks.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps, Power CAT
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-procode-eval@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use eval-generator-gen-pages: Generate presence, unit, and security checks."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-procode-eval/skills/eval-generator-gen-pages (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-52

### Preview Screens (`preview-screens`)

- **What it does:** Review generated screens without running Metro.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use preview-screens: Review generated screens without running Metro."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/preview-screens (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-31

### Test Native Extension (`test-native-extension`)

- **What it does:** Run structural, manifest, contract, and PCF validation before native builds.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use test-native-extension: Run structural, manifest, contract, and PCF validation before native builds."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/test-native-extension (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-44
