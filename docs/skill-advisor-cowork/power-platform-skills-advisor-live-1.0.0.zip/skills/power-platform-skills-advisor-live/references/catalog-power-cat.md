# Power CAT catalog (16 items)

Catalog refreshed on 26 Oct 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> Power CAT skills sit beside product builders to modernize, review, govern, and communicate.

### Dataverse WebAPI Query (`dataverse-webapi-query`)

- **What it does:** Author OData and FetchXML across apps, flows, and APIs.
- **Purpose:** Author | **Tier:** skill | **Products:** Dataverse, Power CAT
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-dataverse@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-dataverse/skills/dataverse-webapi-query (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-82

### Design Guide (`design-guide`)

- **What it does:** Establish brand tokens before generating a Code App.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT
- **Personas:** Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-code-apps@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use code-apps-design-guide: Establish brand tokens before generating a Code App."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-code-apps/skills/design-guide (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-3

### Loop My Prompt (`loop-my-prompt`)

- **What it does:** Rewrite a prompt with explicit outcomes, observable feedback, evidence-based correction and bounded stopping conditions.
- **Purpose:** Author | **Tier:** skill | **Products:** Power CAT
- **Personas:** Developer or maker
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install loop-my-prompt@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use loop-my-prompt: Rewrite a prompt with explicit outcomes, observable feedback, evidence-based correction and bounded stopping conditions."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/loop-my-prompt/skills/loop-my-prompt (verified 26 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-162

### Powercat PP Architecture Advisor (`powercat-pp-architecture-advisor`)

- **What it does:** Design a composed Power Platform solution through adaptive discovery and architecture review.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Power CAT
- **Personas:** QA lead, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-architecture-advisor@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-architecture-advisor/skills/powercat-pp-architecture-advisor (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-106

### Powercat Storytelling (`powercat-storytelling`)

- **What it does:** Convert evidence into brand-matched customer stories.
- **Purpose:** Author | **Tier:** skill | **Products:** Power CAT
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-adoption@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-adoption/skills/powercat-storytelling (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-114

### Create PP Dev Env (`create-pp-dev-env`)

- **What it does:** Provision developer environments with standard governance defaults.
- **Purpose:** Govern | **Tier:** skill | **Products:** Cross-Cutting, Power CAT
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-governance@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-governance/skills/create-pp-dev-env (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-107

### Dev Environment Deprecation Report (`dev-environment-deprecation-report`)

- **What it does:** Report which unmanaged developer environments will be suspended, the apps, flows and agents at risk, and makers over the limit.
- **Purpose:** Govern | **Tier:** skill | **Products:** Cross-Cutting, Power CAT
- **Personas:** Admin
- **Status:** Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-governance@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dev-environment-deprecation-report: Report which unmanaged developer environments will be suspended, the apps, flows and agents at risk, and makers over the limit."
- **Access needed:** Power Platform admin: A user without Power Platform admin rights — the admin connectors will return nothing useful
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-governance/skills/dev-environment-deprecation-report (verified 26 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-161

### InfoPath To Canvas (`infopath-to-canvas`)

- **What it does:** Convert InfoPath forms into modern Canvas Apps.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install Power%20Platform%20Migration%20Factory@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use infopath-to-canvas: Convert InfoPath forms into modern Canvas Apps."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/Power%20Platform%20Migration%20Factory/infopath-to-canvas (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-20

### Migrate To Dataverse (`migrate-to-dataverse`)

- **What it does:** Move SharePoint-backed Canvas Apps toward Dataverse.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install Power%20Platform%20Migration%20Factory@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use migrate-to-dataverse: Move SharePoint-backed Canvas Apps toward Dataverse."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/Power%20Platform%20Migration%20Factory/migrate-to-dataverse (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-21

### PowerCAT Access Migration (`powercat-accessmigration`)

- **What it does:** Migrate an Access .mdb or .accdb database to Dataverse, with an optional model-driven app and approval before writes.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Modernization, Power CAT
- **Personas:** Developer or maker
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-cat-skills@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Migrate my Access database to Dataverse with an optional model-driven app."
- **Source:** https://github.com/microsoft/power-cat-skills/blob/c6c836259e7459bba01305e1d8bf2b9cdbb221e4/Power%20Platform%20Migration%20Factory/Access%20to%20Dataverse%20Migration/SKILL.md (verified 21 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-145

### Power CAT Admin Digest (`Power CAT Admin Digest`)

- **What it does:** Curate health, issues, messages, and deprecations.
- **Purpose:** Operate | **Tier:** skill | **Products:** Cross-Cutting, Power CAT
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-admin-digest@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-admin-digest/skills/powercat-admin-digest (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-112

### PowerCAT OverPage (`PowerCAT OverPage`)

- **What it does:** Six-pillar review: security, performance, accessibility, maintainability, architecture, and reliability.
- **Purpose:** Review | **Tier:** skill | **Products:** Cross-Cutting, Power Pages, Power CAT, Modernization
- **Personas:** QA lead, Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overpage@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overpage: Six-pillar review: security, performance, accessibility, maintainability, architecture, and reliability."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overpage/skills/powercat-overpage (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-12

### PowerCAT Overflow (`PowerCAT Overflow`)

- **What it does:** Review every cloud flow in a solution against coding guidance.
- **Purpose:** Review | **Tier:** skill | **Products:** Cross-Cutting, Power Automate, Power CAT
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overflow@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overflow: Review every cloud flow in a solution against coding guidance."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overflow/skills/powercat-overflow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-11

### Analyze Canvas Performance (`analyze-canvas-performance`)

- **What it does:** Audit delegation, performance, and best practices.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps, Power CAT, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-canvas-apps@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analyze-canvas-performance: Audit delegation, performance, and best practices."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-canvas-apps/skills/analyze-canvas-performance (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-26

### Eval Generator Code App (`eval-generator-code-app`)

- **What it does:** Generate feature, unit, and security evals plus dashboard.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps, Power CAT
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-procode-eval@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use eval-generator-code-app: Generate feature, unit, and security evals plus dashboard."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-procode-eval/skills/eval-generator-code-app (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-50

### Eval Generator Gen Pages (`eval-generator-gen-pages`)

- **What it does:** Generate presence, unit, and security checks.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps, Power CAT
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-procode-eval@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use eval-generator-gen-pages: Generate presence, unit, and security checks."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-procode-eval/skills/eval-generator-gen-pages (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-52
