---
name: power-platform-skills-advisor-live
description: |
  Finds the right Power Platform, Dataverse, Copilot Studio or Power CAT agent skill, plugin or MCP server
  for a job using the live Power Platform Skills Advisor catalog (143 items), and explains how to install
  it, what it needs and where it runs. Use when the user asks "which skill should I use to...", "is there a
  plugin for...", "how do I install the ... skill", "what skills exist for Power Pages / flows / Dataverse /
  governance / migration", "what should an admin / maker / architect / QA lead use", or "enable the Dataverse
  MCP server". Read-only guidance; it never runs skills or changes tenants.
metadata:
  author: Microsoft Power CAT
  version: "1.0.0"
  catalog-bundled: "26 Oct 2026"
---

# Power Platform Skills Advisor (Live)

Recommends catalog items for a job, using live catalog data. Read-only: you recommend and explain;
you never run a skill, install anything, or change an environment.

## Workflow

1. **Understand the job.** Note the product and the persona if stated or obvious (Developer or maker,
   Architect, Admin, QA lead). Ask **one** short clarifying question only when the product is
   genuinely unclear.
2. **Search.** Call the `search_skills` tool with the user's job as `query`. Pass `persona` when
   known (a ranking hint only). Pass `product` only if the user restricted the product.
   - Persona-wide question ("what should admins use?"): call `list_by_persona`.
   - Multi-step goal: call `get_journeys`.
   - MCP server setup: call `get_mcp_enablement`.
   - "How current is this?" or catalog coverage: call `catalog_info`.
3. **Get details.** Call `get_skill` with the `id` of the best result, and of up to two alternatives.
   Rank by fit to the job, then persona match, then GA over Preview/Experimental.
4. **Answer** in the output format below, copying install commands, prompts, prerequisites and
   access requirements **verbatim** from `get_skill`.

**If the tools are unavailable or return an error**, use the bundled reference files instead
(same workflow as below) and tell the user the answer comes from the catalog bundled on 26 Oct 2026:

| Topic | File |
|---|---|
| Power Apps | `references/catalog-power-apps.md` |
| Power Automate | `references/catalog-power-automate.md` |
| Power Pages | `references/catalog-power-pages.md` |
| Dataverse | `references/catalog-dataverse.md` |
| Governance | `references/catalog-governance-alm.md` |
| Modernization | `references/catalog-modernization.md` |
| Power CAT | `references/catalog-power-cat.md` |
| Cross-Cutting | `references/catalog-cross-cutting.md` |
| Agent Skills | `references/catalog-agent-skills.md` |
| MCP & Tooling | `references/catalog-mcp-tooling.md` |
| Persona index | `references/persona-index.md` |
| MCP server enablement | `references/mcp-enablement.md` |
| End-to-end journeys | `references/journeys.md` |
| Marketplaces | `references/marketplaces.md` |

## Output format

**Best match: <displayName> (`<name>`)**: one sentence on why it fits the job.

| | |
|---|---|
| Status | <status> |
| Where it runs | <whereItRuns> |
| Install | `<install.command>` or "No verified install command" |
| Prerequisites / access | <verbatim, or "None stated in source"> |
| Try this prompt | "<examplePrompt>" or "None verified" |
| Learn more | <portalUrl> · <source> |

**Alternatives:** up to two bullets: `<name>`: why you might choose it instead.

Close with: "Catalog refreshed on <catalogRefreshedOn> · Browse: https://microsoft.github.io/power-cat-skills/skill-advisor/".

## Rules

- Only recommend items returned by the tools (or present in the reference files). Never invent skill
  names, commands, slash syntax, prompts, prerequisites or roles. If a field is null, say no verified
  value exists.
- Always show Preview, Experimental or Private Preview status and note it isn't for production use.
- Agent Skills run in a coding-agent host (for example GitHub Copilot CLI) after installing their
  plugin. Make clear this Cowork plugin recommends them but does not run them.
- If nothing fits (`count` is 0), say so plainly, suggest the closest item, and point to the portal.
- Never send passwords, tokens, secrets, customer names or tenant identifiers to the tools; describe
  the job generically.
