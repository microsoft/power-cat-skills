# Power Automate catalog (27 items)

Catalog refreshed on 16 Nov 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> Read each automation scope horizontally from discovery and build through review and operations.

### Derive Metric (`derive-metric`)

- **What it does:** Reuse saved metrics or run a validated ephemeral formula.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Automate
- **Personas:** Developer or maker, QA lead
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install process-intelligence@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use derive-metric: Reuse saved metrics or run a validated ephemeral formula."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/process-intelligence/skills/derive-metric (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-226

### Browse Flows (`browse-flows`)

- **What it does:** Browse environments, flows, connections, and runs.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use browse-flows: Browse environments, flows, connections, and runs."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/browse-flows (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-55

### Build Flow (`build-flow`)

- **What it does:** Generate a complete cloud flow through FlowAgent.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Cross-Cutting, Power Automate
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use build-flow: Generate a complete cloud flow through FlowAgent."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/build-flow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-8

### connection lifecycle (`connection lifecycle`)

- **What it does:** Discover, share, fix, and map connections.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-64

### Create Flow (`create-flow`)

- **What it does:** Guided creation with explicit choices and connection mapping.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-flow: Guided creation with explicit choices and connection mapping."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/create-flow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-56

### Debug Flow (`debug-flow`)

- **What it does:** Interactively inspect a failed run and its actions.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use debug-flow: Interactively inspect a failed run and its actions."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/debug-flow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-61

### Diagnose Flow (`diagnose-flow`)

- **What it does:** Diagnose failed runs, loops, connections, and expressions.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Cross-Cutting, Power Automate
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use diagnose-flow: Diagnose failed runs, loops, connections, and expressions."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/diagnose-flow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-17

### expression help (`expression help`)

- **What it does:** Validate Workflow Definition Language expressions.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-57

### Manage Desktop Flows (`manage-desktop-flows`)

- **What it does:** List and run desktop-flow assets.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use manage-desktop-flows: List and run desktop-flow assets."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/manage-desktop-flows (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-60

### Route Environments (`route-environments`)

- **What it does:** Resolve the correct environment before any lifecycle action.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate, Cross-Cutting
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use route-environments: Resolve the correct environment before any lifecycle action."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/route-environments (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-63

### Setup (`setup`)

- **What it does:** Verify Node, Azure CLI login, environment, and FlowAgent MCP.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Automate
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup: Verify Node, Azure CLI login, environment, and FlowAgent MCP."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/setup (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-54

### Admin Digest (`Admin Digest`)

- **What it does:** Prioritize Message Center, health, issues, and deprecations.
- **Purpose:** Operate | **Tier:** skill | **Products:** Cross-Cutting, Power Automate, Governance, Modernization
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-admin-digest@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-admin-digest/skills/powercat-admin-digest (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-19

### Manage Flows (`manage-flows`)

- **What it does:** Publish, disable, copy, inventory, test, and batch operations.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Automate, Governance
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use manage-flows: Publish, disable, copy, inventory, test, and batch operations."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/manage-flows (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-59

### Report Issue · Power Automate (`report-issue`)

- **What it does:** Draft a bug report for the power-automate plugin.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Automate
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use report-issue: Draft a bug report for the power-automate plugin."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/report-issue (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-223

### Report Issue · Process Intelligence (`report-issue`)

- **What it does:** Prepare a support draft for a failed Process Intelligence operation.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Automate
- **Personas:** Developer or maker
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install process-intelligence@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use report-issue: Prepare a support draft for a failed Process Intelligence operation."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/process-intelligence/skills/report-issue (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-233

### resubmit / cancel (`resubmit / cancel`)

- **What it does:** Control problematic or recoverable runs.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Automate
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-62

### Setup · Process Intelligence (`setup`)

- **What it does:** Configure, sign in to and diagnose the Process Intelligence connection.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Automate
- **Personas:** Admin
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install process-intelligence@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup: Configure, sign in to and diagnose the Process Intelligence connection."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/process-intelligence/skills/setup (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-224

### Telemetry · Power Automate (`telemetry`)

- **What it does:** Enable, disable or check the power-automate plugin's usage telemetry.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-automate@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use telemetry: Enable, disable or check the power-automate plugin's usage telemetry."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-automate/skills/telemetry (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-222

### Findings viewer (`Findings viewer`)

- **What it does:** Prioritize findings by pillar, flow, and remediation.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overflow@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overflow: Prioritize findings by pillar, flow, and remediation."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overflow/skills/powercat-overflow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-58

### PowerCAT Overflow (`PowerCAT Overflow`)

- **What it does:** Review every cloud flow in a solution against coding guidance.
- **Purpose:** Review | **Tier:** skill | **Products:** Cross-Cutting, Power Automate, Power CAT
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overflow@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overflow: Review every cloud flow in a solution against coding guidance."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overflow/skills/powercat-overflow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-11

### Process Analytics (`analytics`)

- **What it does:** Select a process, get an overview and route follow-up questions.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install process-intelligence@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analytics: Select a process, get an overview and route follow-up questions."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/process-intelligence/skills/analytics (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-225

### Analyze Drivers (`analyze-drivers`)

- **What it does:** Investigate which case attributes relate to delays or rework.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install process-intelligence@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analyze-drivers: Investigate which case attributes relate to delays or rework."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/process-intelligence/skills/analyze-drivers (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-230

### Analyze Objects (`analyze-objects`)

- **What it does:** Analyze object-centric executions and cross-object delay.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install process-intelligence@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analyze-objects: Analyze object-centric executions and cross-object delay."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/process-intelligence/skills/analyze-objects (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-232

### Analyze Performance · Process Mining (`analyze-performance`)

- **What it does:** Find slow activities, waiting, handoffs and bottlenecks.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install process-intelligence@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analyze-performance: Find slow activities, waiting, handoffs and bottlenecks."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/process-intelligence/skills/analyze-performance (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-228

### Analyze Variants (`analyze-variants`)

- **What it does:** Compare variants, examine rework and find a specific case.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install process-intelligence@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analyze-variants: Compare variants, examine rework and find a specific case."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/process-intelligence/skills/analyze-variants (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-229

### Compare Cohorts (`compare-cohorts`)

- **What it does:** Compare matched groups or time periods in a process.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install process-intelligence@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use compare-cohorts: Compare matched groups or time periods in a process."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/process-intelligence/skills/compare-cohorts (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-231

### Investigate Process (`investigate-process`)

- **What it does:** Test a business hypothesis across analytical perspectives.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Automate
- **Personas:** QA lead
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install process-intelligence@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use investigate-process: Test a business hypothesis across analytical perspectives."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/process-intelligence/skills/investigate-process (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-227
