# Persona index

Catalog refreshed on 16 Nov 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

Persona is an editorial tag. Treat it as a ranking hint, never as a filter that hides a good match.

## Developer or maker (121)

| Item | Purpose | Products | Status |
|---|---|---|---|
| `MCP Apps` | Author | Cross-Cutting | GA |
| `Power CAT Storytelling` | Author | Cross-Cutting, Modernization | GA |
| `add-ai-webapi` | Build | Power Pages | GA |
| `add-azuredevops` | Build | Power Apps | GA |
| `add-camera` | Build | Power Apps | Preview |
| `add-cloud-flow` | Build | Power Pages | GA |
| `add-connector` | Build | Power Apps | Preview |
| `add-connector` | Build | Cross-Cutting | GA |
| `add-data-source` | Mcp | Power Apps | GA |
| `add-datasource` | Build | Power Apps | GA |
| `add-datasource` | Build | Power Apps | Preview |
| `add-dataverse` | Build | Power Apps | GA |
| `add-dataverse` | Build | Power Apps | Preview |
| `add-excel` | Build | Power Apps | GA |
| `add-geolocation` | Build | Power Apps | Preview |
| `add-knowledge` | Author | Agent Skills | Preview |
| `add-localization` | Build | Power Pages | GA |
| `add-mcscopilot` | Build | Power Apps | GA |
| `add-native` | Build | Power Apps | Preview |
| `add-office365` | Build | Power Apps | GA |
| `add-onedrive` | Build | Power Apps | GA |
| `add-pdf-report` | Build | Power Apps | Preview |
| `add-pdf-viewer` | Build | Power Apps | Preview |
| `add-pen-input` | Build | Power Apps | Preview |
| `add-sample-data` | Build | Dataverse, Modernization | GA |
| `add-sample-data` | Build | Power Apps | Preview |
| `add-seo` | Build | Power Pages | GA |
| `add-server-logic` | Build | Power Pages | GA |
| `add-sharepoint` | Build | Power Apps | GA |
| `add-sharepoint` | Build | Power Apps | Preview |
| `add-teams` | Build | Power Apps | GA |
| `add-workiq` | Build | Power Apps | GA |
| `agent-skills-standard` | Author | Agent Skills | GA |
| `ai-webapi-integration` | Build | Power Pages | GA |
| `airtable-to-power-platform` | Migrate | Modernization | GA |
| `app-builder` | Build | Power Apps | Preview |
| `author` | Mcp | MCP & Tooling | GA |
| `author-webpage-content` | Build | Power Pages | GA |
| `build-android-binary` | Build | Power Apps | GA |
| `build-flow` | Mcp | Cross-Cutting, Power Automate | GA |
| `build-ios-binary` | Build | Power Apps | GA |
| `canvas-app-planner` | Build | Power Apps | GA |
| `canvas-create-builder` | Build | Power Apps | GA |
| `canvas-create-discovery` | Build | Power Apps | GA |
| `canvas-create-functionality` | Build | Power Apps | GA |
| `canvas-create-layout` | Build | Power Apps | GA |
| `canvas-create-screens` | Build | Power Apps | GA |
| `canvas-screen-builder` | Build | Power Apps | GA |
| `clone-agent` | Build | Agent Skills | Preview |
| `code-app-architect` | Build | Power Apps | GA |
| `configure-canvas-mcp` | Operate | Power Apps | GA |
| `connect` | Mcp | MCP & Tooling | GA |
| `copilot-studio-init` | Build | Agent Skills | Preview |
| `create-agent` | Author | Agent Skills | Preview |
| `create-code-app` | Build | Cross-Cutting, Power Apps | GA |
| `create-mobile-app` | Build | Power Apps | Preview |
| `create-pcf` | Build | Power Apps, Power CAT | Unspecified |
| `create-site` | Build | Cross-Cutting, Power Pages | GA |
| `data-model-architect` | Build | Power Apps | Preview |
| `data-model-architect` | Build | Power Pages | GA |
| `dataverse-webapi-query` | Author | Dataverse, Power CAT | GA |
| `delete-agent` | Operate | Agent Skills | Preview |
| `derive-metric` | Build | Power Automate | Unspecified |
| `describe / list` | Mcp | MCP & Tooling | GA |
| `dv-connect` | Mcp | Dataverse | GA |
| `dv-data` | Operate | Dataverse, Modernization | GA |
| `dv-metadata` | Build | Cross-Cutting, Power Apps, Dataverse, Modernization | GA |
| `dv-overview` | Author | Dataverse | GA |
| `dv-query` | Mcp | Dataverse | GA |
| `dv-tool-selection` | Operate | MCP & Tooling | GA |
| `edit-app` | Build | Power Apps | Preview |
| `edit-site` | Build | Power Pages | GA |
| `generate-canvas-app` | Build | Power Apps | GA |
| `generate-codeful-mcp-tool` | Build | MCP & Tooling | Unspecified |
| `generate-mcp-app-ui` | Author | Agent Skills, MCP & Tooling | GA |
| `generate-native-extension` | Build | Power Apps | GA |
| `generate-pcf-companion` | Build | Power Apps | GA |
| `generate-ppmplugin` | Build | Power Apps | GA |
| `generate-ppmplugin-manifest` | Build | Power Apps | GA |
| `genpage` | Build | Cross-Cutting, Power Apps | GA |
| `genpage-connector-builder` | Build | Power Apps | GA |
| `genpage-customapi-builder` | Build | Power Apps | GA |
| `genpage-edit-planner` | Build | Power Apps | GA |
| `genpage-entity-builder` | Build | Power Apps | GA |
| `genpage-page-builder` | Build | Power Apps | GA |
| `genpage-planner` | Build | Power Apps | GA |
| `host protocol` | Mcp | MCP & Tooling | GA |
| `infopath-to-canvas` | Migrate | Cross-Cutting, Power Apps, Power CAT, Modernization | GA |
| `integrate-backend` | Build | Power Pages | GA |
| `integrate-webapi` | Build | Power Pages | GA |
| `loop-my-prompt` | Author | Power CAT | Unspecified |
| `manage-desktop-flows` | Mcp | Power Automate | GA |
| `mcp-servers` | Reference | MCP & Tooling | GA |
| `mcs-assistant` | Author | Cross-Cutting, Agent Skills | Preview |
| `migrate-to-dataverse` | Migrate | Cross-Cutting, Power Apps, Power CAT, Modernization | GA |
| `native-app-planner` | Build | Power Apps | Preview |
| `offline-profile-architect` | Build | Power Apps | Preview |
| `operate` | Mcp | MCP & Tooling | GA |
| `pcf` | Build | Power Apps | Preview |
| `powercat-accessmigration` | Migrate | Modernization, Power CAT | Unspecified |
| `powercat-codeappscompact` | Build | Power Apps, Power CAT | Unspecified |
| `powercat-skills-router` | Operate | Power CAT | Unspecified |
| `powercat-storytelling` | Author | Power CAT | GA |
| `pull-agent` | Build | Agent Skills | Preview |
| `query / data` | Mcp | MCP & Tooling | GA |
| `report-issue` | Operate | Power Apps | Preview |
| `report-issue` | Operate | Power Apps | GA |
| `report-issue` | Operate | Power Apps | GA |
| `report-issue` | Operate | MCP & Tooling | GA |
| `report-issue` | Operate | Power Apps | Preview |
| `report-issue` | Operate | Power Apps | Unspecified |
| `report-issue` | Operate | Power Automate | GA |
| `report-issue` | Operate | Power Automate | Unspecified |
| `report-issue` | Operate | Power Pages | GA |
| `resubmit / cancel` | Operate | Power Automate | GA |
| `screen-builder` | Build | Power Apps | Preview |
| `screen-planner` | Build | Power Apps | Preview |
| `setup-app-insights` | Operate | Power Apps | Preview |
| `setup-datamodel` | Build | Power Pages, Dataverse | GA |
| `setup-datamodel` | Build | Power Apps | Preview |
| `webapi-integration` | Build | Power Pages | GA |

## Architect (30)

| Item | Purpose | Products | Status |
|---|---|---|---|
| `Copilot migration plan` | Migrate | Modernization | GA |
| `PowerCAT OverPage` | Review | Cross-Cutting, Power Pages, Power CAT, Modernization | GA |
| `ai-webapi-settings-architect` | Govern | Power Pages | GA |
| `canvas-app` | Mcp | Cross-Cutting, Power Apps, Modernization | GA |
| `canvas-app-planner` | Build | Power Apps | GA |
| `canvas-create-layout` | Build | Power Apps | GA |
| `code-app-architect` | Build | Power Apps | GA |
| `data-model-architect` | Build | Power Apps | Preview |
| `data-model-architect` | Build | Power Pages | GA |
| `design-guide` | Author | Cross-Cutting, Power Apps, Power CAT | GA |
| `design-native-extension-feature` | Author | Power Apps | GA |
| `design-system` | Author | Power Apps | Preview |
| `dv-metadata` | Build | Cross-Cutting, Power Apps, Dataverse, Modernization | GA |
| `edit-app` | Build | Power Apps | Preview |
| `edit-site` | Build | Power Pages | GA |
| `exceptional-web-design` | Review | Power Pages | GA |
| `genpage` | Build | Cross-Cutting, Power Apps | GA |
| `genpage-edit-planner` | Build | Power Apps | GA |
| `genpage-page-builder` | Build | Power Apps | GA |
| `genpage-planner` | Build | Power Apps | GA |
| `mcs-assistant architect` | Author | Modernization | Preview |
| `offline-profile-architect` | Build | Power Apps | Preview |
| `plan-alm` | Govern | Cross-Cutting, Power Pages, Dataverse, Governance | GA |
| `powercat-pp-architecture-advisor` | Author | Cross-Cutting, Power CAT | GA |
| `pp-well-architected` | Review | Cross-Cutting | GA |
| `screen-planner` | Build | Power Apps | Preview |
| `setup-datamodel` | Build | Power Pages, Dataverse | GA |
| `setup-datamodel` | Build | Power Apps | Preview |
| `table-permissions-architect` | Govern | Power Pages | GA |
| `webapi-settings-architect` | Govern | Power Pages | GA |

## Admin (68)

| Item | Purpose | Products | Status |
|---|---|---|---|
| `Admin Digest` | Operate | Cross-Cutting, Power Automate, Governance, Modernization | GA |
| `Power CAT Admin Digest` | Operate | Cross-Cutting, Power CAT | GA |
| `PowerCAT OverPage` | Review | Cross-Cutting, Power Pages, Power CAT, Modernization | GA |
| `Pro-Code Eval` | Review | Cross-Cutting, Governance | GA |
| `activate-site` | Deploy | Power Pages | GA |
| `add-skill` | Deploy | Agent Skills | Preview |
| `add-table-to-offline-profile` | Deploy | Power Apps | Preview |
| `ai-webapi-settings-architect` | Govern | Power Pages | GA |
| `assemble-ppmplugin` | Deploy | Power Apps | GA |
| `assign-offline-profile` | Deploy | Power Apps | Preview |
| `audit-permissions` | Review | Power Pages, Governance | GA |
| `browse-flows` | Mcp | Power Automate | GA |
| `compile_canvas` | Mcp | Power Apps | GA |
| `configure-env-variables` | Deploy | Power Pages | GA |
| `connect` | Mcp | MCP & Tooling | GA |
| `connection lifecycle` | Mcp | Power Automate | GA |
| `copilot-studio-manage` | Deploy | Agent Skills | Preview |
| `create-flow` | Mcp | Power Automate | GA |
| `create-pp-dev-env` | Govern | Cross-Cutting, Power CAT | GA |
| `create-webroles` | Govern | Power Pages | GA |
| `deploy` | Deploy | Cross-Cutting, Power Apps | GA |
| `deploy` | Deploy | Governance | GA |
| `deploy + Wrap` | Deploy | Power Apps | Preview |
| `deploy-pipeline` | Deploy | Power Pages | GA |
| `deploy-site` | Deploy | Cross-Cutting, Power Pages | GA |
| `dev-environment-deprecation-report` | Govern | Cross-Cutting, Power CAT | Preview |
| `diagnose` | Mcp | MCP & Tooling | GA |
| `diagnose-deployment` | Operate | Power Pages | GA |
| `diagnose-flow` | Mcp | Cross-Cutting, Power Automate | GA |
| `dv-admin` | Operate | Dataverse, Cross-Cutting, Governance | GA |
| `dv-admin + dv-security` | Operate | Cross-Cutting | GA |
| `dv-security` | Govern | Dataverse, Governance, Modernization | GA |
| `dv-solution` | Deploy | Cross-Cutting, Dataverse, Governance | GA |
| `edit-offline-profile` | Deploy | Power Apps | Preview |
| `enable-tables-offline` | Deploy | Power Apps | Preview |
| `ensure-pipelines-host` | Govern | Power Pages | GA |
| `erp-sql` | Operate | Dataverse | GA |
| `erp-xpp` | Deploy | Dataverse | GA |
| `eval-generator-code-app` | Review | Power Apps, Power CAT | GA |
| `eval-generator-gen-pages` | Review | Power Apps, Power CAT | GA |
| `export-solution` | Deploy | Power Pages | GA |
| `force-link-environment` | Govern | Power Pages | GA |
| `genpage-upload.js` | Deploy | Power Apps | GA |
| `import-solution` | Deploy | Power Pages | GA |
| `integrate-webapi` | Build | Power Pages | GA |
| `list-connections` | Operate | Cross-Cutting | GA |
| `list-connections` | Operate | Power Apps | Preview |
| `manage-firewall` | Govern | Power Pages | GA |
| `manage-headers / firewall` | Govern | Power Pages | GA |
| `open-wrap-url` | Deploy | Power Apps | Preview |
| `pcf` | Build | Power Apps | Preview |
| `plan-alm` | Govern | Cross-Cutting, Power Pages, Dataverse, Governance | GA |
| `pp-skills-setup-host` | Govern | MCP & Tooling | GA |
| `publish-agent` | Deploy | Agent Skills | Preview |
| `publish-pcf-companion` | Deploy | Power Apps | GA |
| `push-agent` | Deploy | Agent Skills | Preview |
| `route-environments` | Mcp | Power Automate, Cross-Cutting | GA |
| `scan-site` | Review | Power Pages | GA |
| `security-review` | Review | Power Pages, Governance | GA |
| `set-app-registration-native` | Deploy | Power Apps | Preview |
| `setup` | Mcp | Power Automate | GA |
| `setup` | Operate | Power Automate | Unspecified |
| `setup-auth` | Govern | Power Pages | GA |
| `setup-offline-profile` | Deploy | Power Apps | Preview |
| `setup-pipeline` | Deploy | Power Pages, Cross-Cutting, Governance | GA |
| `setup-solution` | Deploy | Power Pages | GA |
| `table-permissions-architect` | Govern | Power Pages | GA |
| `webapi-settings-architect` | Govern | Power Pages | GA |

## QA lead (60)

| Item | Purpose | Products | Status |
|---|---|---|---|
| `Canvas performance` | Review | Governance, Modernization | GA |
| `Copilot Studio chat` | Review | Modernization | Preview |
| `Copilot Studio describe` | Review | Modernization | Preview |
| `Copilot Studio migrate` | Migrate | Cross-Cutting | Preview |
| `Findings viewer` | Review | Power Automate | GA |
| `HAR-assisted analysis` | Review | Power Pages | GA |
| `OverPage` | Review | Governance | GA |
| `Overflow` | Review | Governance | GA |
| `PowerCAT OverPage` | Review | Cross-Cutting, Power Pages, Power CAT, Modernization | GA |
| `PowerCAT Overflow` | Review | Cross-Cutting, Power Automate, Power CAT | GA |
| `Pro-Code Eval` | Review | Cross-Cutting, Governance | GA |
| `Skill Recorder` | Author | Cross-Cutting, Agent Skills, Modernization | GA |
| `add-ai-webapi` | Build | Power Pages | GA |
| `analytics` | Review | Power Automate | Unspecified |
| `analyze-canvas-performance` | Review | Power Apps, Power CAT, Modernization | GA |
| `analyze-drivers` | Review | Power Automate | Unspecified |
| `analyze-objects` | Review | Power Automate | Unspecified |
| `analyze-performance` | Review | Power Pages | GA |
| `analyze-performance` | Review | Power Automate | Unspecified |
| `analyze-variants` | Review | Power Automate | Unspecified |
| `app-builder` | Build | Power Apps | Preview |
| `audit-permissions` | Review | Power Pages, Governance | GA |
| `audit-ppmplugin` | Review | Power Apps | GA |
| `canvas-create-discovery` | Build | Power Apps | GA |
| `check-updates` | Operate | Power Apps | Preview |
| `compare-cohorts` | Review | Power Automate | Unspecified |
| `compare-site-configurations` | Review | Power Pages | GA |
| `compile / sync` | Mcp | MCP & Tooling | GA |
| `compile_canvas` | Mcp | Power Apps | GA |
| `debug-app` | Review | Power Apps | Preview |
| `debug-app / diagnose-flow` | Review | Governance | GA |
| `debug-extension` | Review | Power Apps | GA |
| `debug-flow` | Mcp | Power Automate | GA |
| `derive-metric` | Build | Power Automate | Unspecified |
| `dv-solution` | Deploy | Cross-Cutting, Dataverse, Governance | GA |
| `eval-generator-code-app` | Review | Power Apps, Power CAT | GA |
| `eval-generator-gen-pages` | Review | Power Apps, Power CAT | GA |
| `exceptional-web-design` | Review | Power Pages | GA |
| `expression help` | Mcp | Power Automate | GA |
| `generate-ppmplugin-manifest` | Build | Power Apps | GA |
| `investigate-process` | Review | Power Automate | Unspecified |
| `manage-flows` | Operate | Power Automate, Governance | GA |
| `migrate-bootstrap` | Migrate | Modernization | GA |
| `migrate-webapi-selectall` | Review | Power Pages | GA |
| `pcf` | Build | Power Apps | Preview |
| `powercat-pp-architecture-advisor` | Author | Cross-Cutting, Power CAT | GA |
| `pp-well-architected` | Review | Cross-Cutting | GA |
| `preview-offline-scope` | Review | Power Apps | Preview |
| `preview-screens` | Review | Power Apps | Preview |
| `scan-code` | Review | Power Pages | GA |
| `scan-site` | Review | Power Pages | GA |
| `security-review` | Review | Power Pages, Governance | GA |
| `telemetry` | Operate | Power Apps | Preview |
| `telemetry` | Operate | Power Apps | Preview |
| `telemetry` | Operate | Power Apps | GA |
| `telemetry` | Operate | Power Apps | Unspecified |
| `telemetry` | Operate | Power Automate | GA |
| `telemetry` | Operate | Power Pages | GA |
| `test-native-extension` | Review | Power Apps | GA |
| `test-site` | Review | Power Pages, Governance, Modernization | GA |

