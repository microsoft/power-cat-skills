# Power Apps catalog (99 items)

Catalog refreshed on 17 Nov 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> Read each app surface horizontally from plan and build through review and release.

### Design Guide (`design-guide`)

- **What it does:** Establish brand tokens before generating a Code App.
- **Purpose:** Author | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT
- **Personas:** Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-code-apps@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use code-apps-design-guide: Establish brand tokens before generating a Code App."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-code-apps/skills/design-guide (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-3

### Design Native Extension Feature (`design-native-extension-feature`)

- **What it does:** Create and approve the product requirements and cross-platform technical design.
- **Purpose:** Author | **Tier:** skill | **Products:** Power Apps
- **Personas:** Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use design-native-extension-feature: Create and approve the product requirements and cross-platform technical design."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/design-native-extension-feature (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-37

### Design System (`design-system`)

- **What it does:** Choose a visual direction and generate branded design tokens.
- **Purpose:** Author | **Tier:** skill | **Products:** Power Apps
- **Personas:** Architect
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use design-system: Choose a visual direction and generate branded design tokens."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/design-system (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-28

### Add Azure DevOps (`add-azuredevops`)

- **What it does:** Add the Azure DevOps connector to a code app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-azuredevops: Add the Azure DevOps connector to a code app."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/add-azuredevops (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-184

### Add Camera (`add-camera`)

- **What it does:** Camera, image picker and barcode/QR scanning for add-native.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-native/add-camera (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-200

### add-connector · Mobile (`add-connector`)

- **What it does:** Add Power Platform connectors and generated services.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-connector: Add Power Platform connectors and generated services."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-connector (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-30

### Add Datasource (`add-datasource`)

- **What it does:** Connect Dataverse, SharePoint, Teams, Excel, or other services.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-datasource: Connect Dataverse, SharePoint, Teams, Excel, or other services."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/add-datasource (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-49

### Add Data Source · Mobile (`add-datasource`)

- **What it does:** Route an unspecified data source to Dataverse, SharePoint or a connector.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-datasource: Route an unspecified data source to Dataverse, SharePoint or a connector."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-datasource (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-190

### Add Dataverse · Code Apps (`add-dataverse`)

- **What it does:** Add Dataverse tables with generated TypeScript models and services.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-dataverse: Add Dataverse tables with generated TypeScript models and services."
- **Access needed:** Dataverse role: Requires System Administrator or System Customizer security role.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/add-dataverse (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-178

### Add Dataverse · Mobile (`add-dataverse`)

- **What it does:** Add existing or new Dataverse tables to a mobile app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-dataverse: Add existing or new Dataverse tables to a mobile app."
- **Access needed:** Dataverse role: Requires the user to hold System Administrator or System Customizer in this environment.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-dataverse (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-191

### Add Excel (`add-excel`)

- **What it does:** Add the Excel Online (Business) connector to a code app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-excel: Add the Excel Online (Business) connector to a code app."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/add-excel (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-180

### Add Geolocation (`add-geolocation`)

- **What it does:** Background GPS tracking with durable storage for add-native.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-native/add-geolocation (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-201

### Add Copilot Studio (`add-mcscopilot`)

- **What it does:** Add a Copilot Studio agent connector to a code app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-mcscopilot: Add a Copilot Studio agent connector to a code app."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/add-mcscopilot (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-185

### Add Native Capability (`add-native`)

- **What it does:** Add camera, scanner, GPS, PDF or pen capabilities to a mobile app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-native: Add camera, scanner, GPS, PDF or pen capabilities to a mobile app."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-native (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-195

### Add Office 365 Outlook (`add-office365`)

- **What it does:** Add the Office 365 Outlook connector to a code app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-office365: Add the Office 365 Outlook connector to a code app."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/add-office365 (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-183

### Add OneDrive (`add-onedrive`)

- **What it does:** Add the OneDrive for Business connector to a code app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-onedrive: Add the OneDrive for Business connector to a code app."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/add-onedrive (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-181

### Add PDF Report (`add-pdf-report`)

- **What it does:** App-generated PDF report workflows for add-native.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-native/add-pdf-report (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-202

### Add PDF Viewer (`add-pdf-viewer`)

- **What it does:** Native PDF viewing for add-native.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-native/add-pdf-viewer (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-203

### Add Pen Input (`add-pen-input`)

- **What it does:** Pen, signature and handwriting capture for add-native.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-native/add-pen-input (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-204

### Add Sample Data · Mobile (`add-sample-data`)

- **What it does:** Seed Dataverse tables with realistic sample records for a new app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-sample-data: Seed Dataverse tables with realistic sample records for a new app."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-sample-data (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-196

### Add SharePoint · Code Apps (`add-sharepoint`)

- **What it does:** Add the SharePoint Online connector to a code app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-sharepoint: Add the SharePoint Online connector to a code app."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/add-sharepoint (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-179

### Add SharePoint · Mobile (`add-sharepoint`)

- **What it does:** Read or write SharePoint lists and documents from a mobile app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-sharepoint: Read or write SharePoint lists and documents from a mobile app."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-sharepoint (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-192

### Add Teams (`add-teams`)

- **What it does:** Add the Microsoft Teams connector to a code app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-teams: Add the Microsoft Teams connector to a code app."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/add-teams (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-182

### Add Work IQ (`add-workiq`)

- **What it does:** Add Microsoft 365 search and chat through Work IQ.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-workiq: Add Microsoft 365 search and chat through Work IQ."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/add-workiq (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-186

### App Builder (`app-builder`)

- **What it does:** Build or edit a complete model-driven app from a reviewable App Spec.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, QA lead
- **Status:** Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use app-builder: Build or edit a complete model-driven app from a reviewable App Spec."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/model-apps/skills/app-builder (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-51

### Build Android Binary (`build-android-binary`)

- **What it does:** Compile the Android Kotlin module into a runtime-loadable DEX.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use build-android-binary: Compile the Android Kotlin module into a runtime-loadable DEX."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/build-android-binary (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-40

### Build iOS Binary (`build-ios-binary`)

- **What it does:** Compile the iOS module into the flat device-slice framework required by Wrap.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use build-ios-binary: Compile the iOS module into the flat device-slice framework required by Wrap."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/build-ios-binary (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-41

### Canvas App Planner (`canvas-app-planner`)

- **What it does:** Plan scoped edits to an existing Canvas App, including new screens.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/canvas-apps/agents/canvas-app-planner.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-171

### Canvas Create Builder (`canvas-create-builder`)

- **What it does:** Write one new Canvas screen from approved experience decisions.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/canvas-apps/agents/canvas-create-builder.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-177

### Canvas Create Discovery (`canvas-create-discovery`)

- **What it does:** Check experience feasibility against real controls, data and APIs.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/canvas-apps/agents/canvas-create-discovery.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-176

### Canvas Create Functionality (`canvas-create-functionality`)

- **What it does:** Define users, tasks, actions and outcomes for a new Canvas App.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/canvas-apps/agents/canvas-create-functionality.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-173

### Canvas Create Layout (`canvas-create-layout`)

- **What it does:** Design visual hierarchy, regions and responsive layout before control choice.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/canvas-apps/agents/canvas-create-layout.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-175

### Canvas Create Screens (`canvas-create-screens`)

- **What it does:** Group approved intent into task-oriented screens and navigation.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/canvas-apps/agents/canvas-create-screens.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-174

### Canvas Screen Builder (`canvas-screen-builder`)

- **What it does:** Add or modify one screen in an existing Canvas App from a shared contract.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/canvas-apps/agents/canvas-screen-builder.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-172

### Code App Architect (`code-app-architect`)

- **What it does:** Advise on Code App architecture, Dataverse integration and connectors.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/code-apps/com.github.copilot/agents/code-app-architect.agent.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-167

### Create Code App (`create-code-app`)

- **What it does:** Scaffold React/Vite apps with connector-first data access.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-code-app: Scaffold React/Vite apps with connector-first data access."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/create-code-app (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-7

### Create Mobile App (`create-mobile-app`)

- **What it does:** Generate Expo/React Native screens in parallel.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-mobile-app: Generate Expo/React Native screens in parallel."
- **Access needed:** Azure AD admin consent: ...tenant-wide admin consent (Wrap native registration).
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/create-mobile-app (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-29

### Create PCF (`create-pcf`)

- **What it does:** Create or extend accessible virtual PCF controls for model-driven apps.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps, Power CAT
- **Personas:** Developer or maker
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-pcf@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-pcf: Create or extend accessible virtual PCF controls for model-driven apps."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-pcf/skills/create-pcf (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-164

### Data Model Architect · Mobile (`data-model-architect`)

- **What it does:** Propose a Dataverse data model and ER diagram for a mobile app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/mobile-apps/agents/data-model-architect.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-210

### Dv Metadata (`dv-metadata`)

- **What it does:** Design tables, columns, relationships, forms, and views.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Dataverse, Modernization
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Dataverse Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install dataverse@awesome-copilot` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use dv-metadata: Design tables, columns, relationships, forms, and views."
- **Source:** https://github.com/microsoft/Dataverse-skills/blob/main/.github/plugins/dataverse/skills/dv-metadata/SKILL.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-6

### Edit App (`edit-app`)

- **What it does:** Apply safe plan deltas; add offline scope when required.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use edit-app: Apply safe plan deltas; add offline scope when required."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/edit-app (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-34

### Generate Canvas App (`generate-canvas-app`)

- **What it does:** Generate PA YAML screens and controls.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/canvas-apps (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-23

### Generate Native Extension (`generate-native-extension`)

- **What it does:** Generate the Android and iOS native sources plus their manifest dispatch contract.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use generate-native-extension: Generate the Android and iOS native sources plus their manifest dispatch contract."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/generate-native-extension (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-38

### Generate PCF Companion (`generate-pcf-companion`)

- **What it does:** Generate the dispatcher PCF that connects Canvas Apps to the native module.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use generate-pcf-companion: Generate the dispatcher PCF that connects Canvas Apps to the native module."
- **Prerequisite:** The dispatcher PCF is deployed to your environment: run /publish-pcf-companion (handles publisher prefix selection, version bump, env confirmation, and the actual push).
- **Prerequisite:** A wrap build that has the .ppmplugin bundle loaded (the DEX/framework + manifest.json whose <name>/<receiver> this PCF dispatches to) — see /test-native-extension for the load recipe.
- **Prerequisite:** pac auth list shows your test environment as active.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/generate-pcf-companion (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-43

### Generate PPMPlugin (`generate-ppmplugin`)

- **What it does:** Build and verify the native .ppmplugin bundle end to end.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use generate-ppmplugin: Build and verify the native .ppmplugin bundle end to end."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/generate-ppmplugin (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-42

### Generate PPMPlugin Manifest (`generate-ppmplugin-manifest`)

- **What it does:** Validate, reconcile, and stage the .ppmplugin manifest for the selected platforms.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use generate-ppmplugin-manifest: Validate, reconcile, and stage the .ppmplugin manifest for the selected platforms."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/generate-ppmplugin-manifest (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-39

### Genpage (`genpage`)

- **What it does:** Plan a model-driven generative page and its Dataverse shape.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use genpage: Plan a model-driven generative page and its Dataverse shape."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/model-apps/skills/genpage (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-5

### GenPage Connector Builder (`genpage-connector-builder`)

- **What it does:** Discover and bind connectors for a generative page.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/model-apps/agents/genpage-connector-builder.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-218

### GenPage Custom API Builder (`genpage-customapi-builder`)

- **What it does:** Discover and bind Dataverse Custom APIs for a generative page.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/model-apps/agents/genpage-customapi-builder.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-219

### GenPage Edit Planner (`genpage-edit-planner`)

- **What it does:** Plan edits to an existing generative page.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/model-apps/agents/genpage-edit-planner.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-215

### GenPage Entity Builder (`genpage-entity-builder`)

- **What it does:** Create the Dataverse tables, columns and sample data a page needs.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/model-apps/agents/genpage-entity-builder.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-216

### GenPage Page Builder (`genpage-page-builder`)

- **What it does:** Generate one complete .tsx generative page from the plan.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/model-apps/agents/genpage-page-builder.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-217

### GenPage Planner (`genpage-planner`)

- **What it does:** Plan a generative page: requirements, entities and approval.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/model-apps/agents/genpage-planner.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-214

### Native App Planner (`native-app-planner`)

- **What it does:** Gate data, native capabilities, connectors, and screens.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/mobile-apps/agents/native-app-planner.md (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-27

### Offline Profile Architect (`offline-profile-architect`)

- **What it does:** Design an offline profile: row scope, columns and sync frequency.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/mobile-apps/agents/offline-profile-architect.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-212

### PCF Code Components (`pcf`)

- **What it does:** Build, test, deploy and verify Power Apps component framework (PCF) code components from Microsoft templates.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, QA lead, Admin
- **Status:** Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install pcf@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use pcf: Build, test, deploy and verify Power Apps component framework (PCF) code components from Microsoft templates."
- **Access needed:** Power Platform admin (canvas only): For canvas targets after a successful push, ... guide an admin through Power Apps component framework for canvas apps and the user through Studio import/setup.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/pcf/skills/pcf (verified 20 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-154

### PowerCat-CodeAppsCompact (`powercat-codeappscompact`)

- **What it does:** Build React/TypeScript Code Apps with typed workspaces and nested-record editors.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps, Power CAT
- **Personas:** Developer or maker
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-codeappscompact@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-codeappscompact: Build React/TypeScript Code Apps with typed workspaces and nested-record editors."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-codeappscompact/skills/powercat-codeappscompact (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-166

### Screen Builder (`screen-builder`)

- **What it does:** Implement one mobile app screen from its spec.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/mobile-apps/agents/screen-builder.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-213

### Screen Planner (`screen-planner`)

- **What it does:** Plan the screen graph and per-screen specs for a mobile app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/mobile-apps/agents/screen-planner.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-211

### Setup Data Model · Mobile (`setup-datamodel`)

- **What it does:** Plan and approve the Dataverse schema and connectors for a mobile app.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker, Architect
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-datamodel: Plan and approve the Dataverse schema and connectors for a mobile app."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/setup-datamodel (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-189

### Add Table to Offline Profile (`add-table-to-offline-profile`)

- **What it does:** Add one Dataverse table to an existing offline profile.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/add-table-to-offline-profile (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-206

### Assemble PPMPlugin (`assemble-ppmplugin`)

- **What it does:** Reconcile staged binaries, assemble the final bundle, and verify its archive layout.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use assemble-ppmplugin: Reconcile staged binaries, assemble the final bundle, and verify its archive layout."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/assemble-ppmplugin (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-47

### Assign Offline Profile (`assign-offline-profile`)

- **What it does:** Bind users or teams to a Mobile Offline Profile.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/assign-offline-profile (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-208

### deploy · Apps (`deploy`)

- **What it does:** Push Code Apps or Mobile Apps through product tooling.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Cross-Cutting, Power Apps
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use deploy: Push Code Apps or Mobile Apps through product tooling."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/deploy (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-15

### deploy + Wrap (`deploy + Wrap`)

- **What it does:** Build, push, and prepare distribution through Power Apps Wrap.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use deploy: Build, push, and prepare distribution through Power Apps Wrap."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/deploy (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-33

### Edit Offline Profile (`edit-offline-profile`)

- **What it does:** Change one table's offline scope, columns or sync frequency.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/edit-offline-profile (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-207

### Enable Tables Offline (`enable-tables-offline`)

- **What it does:** Enable Dataverse tables for offline sync before profile setup.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/enable-tables-offline (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-205

### genpage-upload.js (`genpage-upload.js`)

- **What it does:** Upload the generated page to its target app through the bundled SDK.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use genpage: Upload the generated page to its target app through the bundled SDK."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/model-apps/skills/genpage (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-53

### Open Wrap URL (`open-wrap-url`)

- **What it does:** Open the Power Apps Wrap page for an app in the active environment.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use open-wrap-url: Open the Power Apps Wrap page for an app in the active environment."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/open-wrap-url (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-198

### Publish PCF Companion (`publish-pcf-companion`)

- **What it does:** Build and publish the dispatcher PCF to the selected Power Platform environment.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use publish-pcf-companion: Build and publish the dispatcher PCF to the selected Power Platform environment."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/publish-pcf-companion (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-48

### Set App Registration (Native) (`set-app-registration-native`)

- **What it does:** Wire an Entra ID app registration to a Wrap mobile app.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use set-app-registration-native: Wire an Entra ID app registration to a Wrap mobile app."
- **Access needed:** Azure tenant admin: Some permission repairs require an Azure tenant admin.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/set-app-registration-native (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-194

### Setup Offline Profile (`setup-offline-profile`)

- **What it does:** Enable offline mode and create a Mobile Offline Profile.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-offline-profile: Enable offline mode and create a Mobile Offline Profile."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/setup-offline-profile (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-197

### Add Data Source (`add-data-source`)

- **What it does:** Discover connectors and live data-source schemas.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/canvas-apps/skills/add-data-source (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-24

### Canvas App (`canvas-app`)

- **What it does:** Plan and coauthor Canvas Apps through the live authoring service.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Cross-Cutting, Power Apps, Modernization
- **Personas:** Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/canvas-apps/skills/canvas-app (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-4

### compile_canvas (`compile_canvas`)

- **What it does:** Validate Canvas YAML before deployment.
- **Purpose:** Mcp | **Tier:** mcp-capability | **Products:** Power Apps
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** MCP capability: used by an agent host connected to the MCP server (see mcp-enablement.md).
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/canvas-apps (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-25

### InfoPath To Canvas (`infopath-to-canvas`)

- **What it does:** Convert InfoPath forms into modern Canvas Apps.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install Power%20Platform%20Migration%20Factory@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use infopath-to-canvas: Convert InfoPath forms into modern Canvas Apps."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/Power%20Platform%20Migration%20Factory/infopath-to-canvas (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-20

### Migrate To Dataverse (`migrate-to-dataverse`)

- **What it does:** Move SharePoint-backed Canvas Apps toward Dataverse.
- **Purpose:** Migrate | **Tier:** skill | **Products:** Cross-Cutting, Power Apps, Power CAT, Modernization
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install Power%20Platform%20Migration%20Factory@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use migrate-to-dataverse: Move SharePoint-backed Canvas Apps toward Dataverse."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/Power%20Platform%20Migration%20Factory/migrate-to-dataverse (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-21

### Check Updates (`check-updates`)

- **What it does:** Check the plugin, native host, Microsoft packages, and direct npm dependencies with per-package approval and rollback.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use check-updates: Check the plugin, native host, Microsoft packages, and direct npm dependencies with per-package approval and rollback."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/check-updates (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-35

### Configure Canvas MCP (`configure-canvas-mcp`)

- **What it does:** Connect the Canvas Authoring MCP server to the app open in Studio.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use configure-canvas-mcp: Connect the Canvas Authoring MCP server to the app open in Studio."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/canvas-apps/skills/configure-canvas-mcp (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-169

### List Connections · Mobile (`list-connections`)

- **What it does:** Find or create a connection ID for a mobile app.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** Admin
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use list-connections: Find or create a connection ID for a mobile app."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/list-connections (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-193

### Report Issue · PCF (`report-issue`)

- **What it does:** File a bug report for the PCF plugin in its GitHub repository.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install pcf@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use report-issue: File a bug report for the PCF plugin in its GitHub repository."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/pcf/skills/report-issue (verified 20 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-155

### Report Issue · Canvas Apps (`report-issue`)

- **What it does:** Draft a bug report for the canvas-apps plugin.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install canvas-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use report-issue: Draft a bug report for the canvas-apps plugin."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/canvas-apps/skills/report-issue (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-170

### Report Issue · Code Apps (`report-issue`)

- **What it does:** Prepare a public bug report for the code-apps plugin.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install code-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use report-issue: Prepare a public bug report for the code-apps plugin."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/code-apps/skills/report-issue (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-187

### Report Issue · Mobile Apps (`report-issue`)

- **What it does:** Prepare a GitHub issue body for the mobile-apps plugin.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use report-issue: Prepare a GitHub issue body for the mobile-apps plugin."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/report-issue (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-199

### Report Issue · Model Apps (`report-issue`)

- **What it does:** Draft a bug report for the model-apps plugin.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use report-issue: Draft a bug report for the model-apps plugin."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/model-apps/skills/report-issue (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-220

### Set Up Application Insights (`setup-app-insights`)

- **What it does:** Configure optional observability for a Power Apps mobile app using an existing, customer-owned Application Insights resource. Off by default; no resource creation.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** Developer or maker
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Enable Application Insights for this app"
- **Source:** https://github.com/microsoft/power-platform-skills/blob/474e614e1f4c0ec193a9ca01caf86b701c79bc26/plugins/mobile-apps/skills/setup-app-insights/SKILL.md (verified 21 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-144

### Telemetry (`telemetry`)

- **What it does:** Enable, disable, or check the mobile-app plugin's usage-data telemetry.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/telemetry (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-36

### Telemetry · PCF (`telemetry`)

- **What it does:** Enable, disable, or check the PCF plugin's usage-data telemetry.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install pcf@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use telemetry: Enable, disable, or check the PCF plugin's usage-data telemetry."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/pcf/skills/telemetry (verified 20 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-156

### Telemetry · Mobile Extension (`telemetry`)

- **What it does:** Enable, disable, or check usage telemetry transmission for the Power Apps Mobile Extension plugin.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use telemetry: Enable, disable, or check usage telemetry transmission for the Power Apps Mobile Extension plugin."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/telemetry (verified 26 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-160

### Telemetry · Model Apps (`telemetry`)

- **What it does:** Enable, disable or check the model-apps plugin's usage telemetry.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Release status not established (Unspecified) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install model-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use telemetry: Enable, disable or check the model-apps plugin's usage telemetry."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/model-apps/skills/telemetry (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-221

### Analyze Canvas Performance (`analyze-canvas-performance`)

- **What it does:** Audit delegation, performance, and best practices.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps, Power CAT, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-canvas-apps@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analyze-canvas-performance: Audit delegation, performance, and best practices."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-canvas-apps/skills/analyze-canvas-performance (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-26

### Audit PPMPlugin (`audit-ppmplugin`)

- **What it does:** Statically audit a built bundle and route findings to the owning stage.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use audit-ppmplugin: Statically audit a built bundle and route findings to the owning stage."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/audit-ppmplugin (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-45

### Debug App (`debug-app`)

- **What it does:** Check routes, payloads, contrast, icons, and runtime issues.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use debug-app: Check routes, payloads, contrast, icons, and runtime issues."
- **Access needed:** tenant admin (conditional): The fix requires a tenant admin action (e.g., AAD consent).
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/debug-app (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-32

### Debug Extension (`debug-extension`)

- **What it does:** Diagnose failures and apply approved fixes across native, manifest, and PCF contracts.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use debug-extension: Diagnose failures and apply approved fixes across native, manifest, and PCF contracts."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/debug-extension (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-46

### Eval Generator Code App (`eval-generator-code-app`)

- **What it does:** Generate feature, unit, and security evals plus dashboard.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps, Power CAT
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-procode-eval@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use eval-generator-code-app: Generate feature, unit, and security evals plus dashboard."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-procode-eval/skills/eval-generator-code-app (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-50

### Eval Generator Gen Pages (`eval-generator-gen-pages`)

- **What it does:** Generate presence, unit, and security checks.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps, Power CAT
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-procode-eval@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use eval-generator-gen-pages: Generate presence, unit, and security checks."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-procode-eval/skills/eval-generator-gen-pages (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-52

### Preview Offline Scope (`preview-offline-scope`)

- **What it does:** Estimate offline download size and sync cost before rollout.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/preview-offline-scope (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-209

### Preview Screens (`preview-screens`)

- **What it does:** Review generated screens without running Metro.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Private Preview (Preview) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install mobile-apps@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use preview-screens: Review generated screens without running Metro."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/mobile-apps/skills/preview-screens (verified 5 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-31

### Test Native Extension (`test-native-extension`)

- **What it does:** Run structural, manifest, contract, and PCF validation before native builds.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Apps
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Apps Mobile Extension
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-apps-mobile-extension@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use test-native-extension: Run structural, manifest, contract, and PCF validation before native builds."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-apps-mobile-extension/skills/test-native-extension (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-44
