# Power Pages catalog (46 items)

Catalog refreshed on 16 Nov 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

> Read each delivery-system boundary horizontally from planning through deployment and operations.

### Add AI Web API (`add-ai-webapi`)

- **What it does:** Add generative-AI search and data summaries to an SPA site (preview APIs).
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker, QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-ai-webapi: Add generative-AI search and data summaries to an SPA site (preview APIs)."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/add-ai-webapi (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-239

### Add Cloud Flow (`add-cloud-flow`)

- **What it does:** Connect notifications or asynchronous processes.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-cloud-flow: Connect notifications or asynchronous processes."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/add-cloud-flow (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-66

### Add Localization (`add-localization`)

- **What it does:** Add languages and a language selector to a code-site SPA.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-localization: Add languages and a language selector to a code-site SPA."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/add-localization (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-235

### Add SEO (`add-seo`)

- **What it does:** Add robots.txt, sitemap, meta and Open Graph tags to an SPA site.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-seo: Add robots.txt, sitemap, meta and Open Graph tags to an SPA site."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/add-seo (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-236

### Add Server Logic (`add-server-logic`)

- **What it does:** Create and manage server-side JavaScript on the Power Pages runtime.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use add-server-logic: Create and manage server-side JavaScript on the Power Pages runtime."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/add-server-logic (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-238

### AI Web API Integration (`ai-webapi-integration`)

- **What it does:** Wire a generative-AI summarization API into site code.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/power-pages/agents/ai-webapi-integration.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-253

### Author Webpage Content (`author-webpage-content`)

- **What it does:** Compose the localized HTML body of an existing non-SPA webpage for edit-site; not a direct user command.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/author-webpage-content (verified 26 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-159

### Create Site (`create-site`)

- **What it does:** Create a modern Power Pages code site.
- **Purpose:** Build | **Tier:** skill | **Products:** Cross-Cutting, Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-site: Create a modern Power Pages code site."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/create-site (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-9

### Data Model Architect · Power Pages (`data-model-architect`)

- **What it does:** Propose a Dataverse data model and ER diagram for a site.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/power-pages/agents/data-model-architect.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-250

### Edit Site (`edit-site`)

- **What it does:** Plan and customize a downloaded non-SPA Power Pages site: pages, content, navigation, templates and styling.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use edit-site: Plan and customize a downloaded non-SPA Power Pages site: pages, content, navigation, templates and styling."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/edit-site (verified 26 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-157

### Integrate Backend (`integrate-backend`)

- **What it does:** Choose Web API, server logic, cloud flow, or a combination.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use integrate-backend: Choose Web API, server logic, cloud flow, or a combination."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/integrate-backend (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-65

### Integrate WebAPI (`integrate-webapi`)

- **What it does:** Create typed clients, services, permissions, and settings.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use integrate-webapi: Create typed clients, services, permissions, and settings."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/integrate-webapi (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-73

### Setup Datamodel (`setup-datamodel`)

- **What it does:** Design Dataverse tables and relationships.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages, Dataverse
- **Personas:** Developer or maker, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-datamodel: Design Dataverse tables and relationships."
- **Prerequisite:** siteType: "spa" — a generated SPA site identified by powerpages.config.json
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/setup-datamodel (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-72

### Web API Integration (`webapi-integration`)

- **What it does:** Generate a typed Web API client and CRUD services for one table.
- **Purpose:** Build | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/power-pages/agents/webapi-integration.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-251

### Activate Site (`activate-site`)

- **What it does:** Provision and activate a Power Pages site with a public URL.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use activate-site: Provision and activate a Power Pages site with a public URL."
- **Access needed:** Site creator role: Insufficient permissions. Inform user they need the "Power Pages site creator" or "System Administrator" role.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/activate-site (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-234

### Configure Environment Variables (`configure-env-variables`)

- **What it does:** Make site settings environment-specific with environment variables.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use configure-env-variables: Make site settings environment-specific with environment variables."
- **Prerequisite:** PAC CLI authenticated: pac auth who
- **Prerequisite:** Azure CLI token available: az account get-access-token
- **Prerequisite:** .solution-manifest.json exists in the project root (run setup-solution first)
- **Prerequisite:** Power Pages site deployed to dev environment (.powerpages-site/ folder exists)
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/configure-env-variables (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-243

### Deploy Pipeline (`deploy-pipeline`)

- **What it does:** Run a Power Platform Pipelines deployment for a site solution.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use deploy-pipeline: Run a Power Platform Pipelines deployment for a site solution."
- **Prerequisite:** .solution-manifest.json exists
- **Prerequisite:** Azure CLI logged in (az account show succeeds)
- **Prerequisite:** PAC CLI logged in (pac env who succeeds)
- **Prerequisite:** "Validate package" — in MULTIRUNMODE this becomes a single parallel batch (Phase 3.6) covering all N non-skipped solutions; in single-solution / legacy v2 mode it runs per-iteration inline in Phase 4
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/deploy-pipeline (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-246

### Deploy Site (`deploy-site`)

- **What it does:** Build and upload a Power Pages code site.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Cross-Cutting, Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use deploy-site: Build and upload a Power Pages code site."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/deploy-site (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-14

### Export Solution (`export-solution`)

- **What it does:** Export a solution with site components as a deployable zip.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use export-solution: Export a solution with site components as a deployable zip."
- **Prerequisite:** PAC CLI installed and authenticated
- **Prerequisite:** Azure CLI installed and logged in
- **Prerequisite:** Solution exists in the environment (run setup-solution first if needed)
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/export-solution (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-244

### Import Solution (`import-solution`)

- **What it does:** Import a solution zip into a target environment.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use import-solution: Import a solution zip into a target environment."
- **Prerequisite:** PAC CLI installed and authenticated to the target environment
- **Prerequisite:** Azure CLI installed and logged in
- **Prerequisite:** Solution zip file exists on disk (produced by export-solution)
- **Prerequisite:** Run az account get-access-token --resource "{environmentUrl}" --query accessToken -o tsv — capture token
- **Prerequisite:** Present target environment URL and ask user to confirm this is correct before proceeding.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/import-solution (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-245

### Setup Pipeline (`setup-pipeline`)

- **What it does:** Configure Power Platform pipelines.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Pages, Cross-Cutting, Governance
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-pipeline: Configure Power Platform pipelines."
- **Prerequisite:** powerpages.config.json exists in the project root
- **Prerequisite:** .solution-manifest.json exists (solution must be created first via setup-solution)
- **Prerequisite:** Azure CLI logged in (az account show succeeds)
- **Prerequisite:** PAC CLI logged in (pac env who succeeds)
- **Prerequisite:** A Power Platform environment with Pipelines package installed (the "host" environment)
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/setup-pipeline (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-80

### Setup Solution (`setup-solution`)

- **What it does:** Create the solution and deployment boundary.
- **Purpose:** Deploy | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-solution: Create the solution and deployment boundary."
- **Prerequisite:** PAC CLI installed and authenticated (pac env who returns an environment URL)
- **Prerequisite:** Azure CLI installed and logged in (az account show succeeds)
- **Prerequisite:** powerpages.config.json exists in the project root (site must be deployed at least once so .powerpages-site/ exists with component records)
- **Prerequisite:** Confirm .powerpages-site/ folder exists (required to find component records)
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/setup-solution (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-76

### AI Web API Settings Architect (`ai-webapi-settings-architect`)

- **What it does:** Propose and create generative-AI summarization site settings.
- **Purpose:** Govern | **Tier:** skill | **Products:** Power Pages
- **Personas:** Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/power-pages/agents/ai-webapi-settings-architect.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-254

### Create WebRoles (`create-webroles`)

- **What it does:** Create roles and access mapping.
- **Purpose:** Govern | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use create-webroles: Create roles and access mapping."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/create-webroles (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-78

### Ensure Pipelines Host (`ensure-pipelines-host`)

- **What it does:** Make sure the tenant has a usable Power Platform Pipelines host.
- **Purpose:** Govern | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use ensure-pipelines-host: Make sure the tenant has a usable Power Platform Pipelines host."
- **Prerequisite:** PAC CLI logged in (pac env who succeeds)
- **Prerequisite:** Azure CLI logged in (az account show succeeds)
- **Prerequisite:** A source Dataverse environment URL (read from powerpages.config.json if invoked from a Power Pages project; passed as arg otherwise)
- **Prerequisite:** One cheap probe: GET {finalHostEnvUrl}/api/data/v9.0/solutions?$filter=uniquename eq 'msdynAppDeploymentAnchor'&$select=version&$top=1 (proves Pipelines is installed AND captures version in one round-trip)
- **Prerequisite:** 200 → cache is valid. Set RESOLUTION from the cached file. Set ACTIONTAKEN = "none". Skip Phases 2–5; jump to Phase 6 with a "reused cached host" summary.
- **Prerequisite:** 404 / 403 / timeout / network → cache is stale or no longer accessible. Continue to Step 1 (full resolution). Do NOT fail — stale cache is expected after env deletion or permission changes.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/ensure-pipelines-host (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-242

### Force-Link Environment (`force-link-environment`)

- **What it does:** Force-link an environment to a Pipelines host.
- **Purpose:** Govern | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use force-link-environment: Force-link an environment to a Pipelines host."
- **Prerequisite:** PAC CLI auth — pac env who must report an authenticated environment (for --dev-env auto-discovery).
- **Prerequisite:** Azure CLI auth — az account show succeeds.
- **Prerequisite:** Host-scoped token — the caller must have Deployment Pipeline Administrator on the target host (the host the env is being linked TO). Without it, ManageEnvironmentStamp returns 403.
- **Access needed:** Pipelines admin: the caller must have Deployment Pipeline Administrator on the target host
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/force-link-environment (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-247

### Manage Firewall (`manage-firewall`)

- **What it does:** Inspect and configure the web application firewall for a site.
- **Purpose:** Govern | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use manage-firewall: Inspect and configure the web application firewall for a site."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/manage-firewall (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-240

### manage-headers / firewall (`manage-headers / firewall`)

- **What it does:** Strengthen browser and network controls.
- **Purpose:** Govern | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use manage-headers: Strengthen browser and network controls."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/manage-headers (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-67

### Plan ALM (`plan-alm`)

- **What it does:** Choose solution boundaries, pipelines, and deployment topology.
- **Purpose:** Govern | **Tier:** skill | **Products:** Cross-Cutting, Power Pages, Dataverse, Governance
- **Personas:** Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use plan-alm: Choose solution boundaries, pipelines, and deployment topology."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/plan-alm (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-2

### Setup Auth (`setup-auth`)

- **What it does:** Configure authentication and identity providers.
- **Purpose:** Govern | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use setup-auth: Configure authentication and identity providers."
- **Access needed:** Azure AD admin consent: Open the API permissions tab -> Grant admin consent for {your tenant}.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/setup-auth (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-77

### Table Permissions Architect (`table-permissions-architect`)

- **What it does:** Plan and create table permissions for web roles.
- **Purpose:** Govern | **Tier:** skill | **Products:** Power Pages
- **Personas:** Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/power-pages/agents/table-permissions-architect.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-255

### Web API Settings Architect (`webapi-settings-architect`)

- **What it does:** Propose and create Web API site settings for tables and columns.
- **Purpose:** Govern | **Tier:** skill | **Products:** Power Pages
- **Personas:** Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent-only: invoked by its parent agent/plugin, not called directly by the user.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/blob/main/plugins/power-pages/agents/webapi-settings-architect.md (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-252

### Diagnose Deployment (`diagnose-deployment`)

- **What it does:** Interpret deployment failures and remediation.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Pages
- **Personas:** Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use diagnose-deployment: Interpret deployment failures and remediation."
- **Prerequisite:** Project root with powerpages.config.json
- **Prerequisite:** PAC CLI installed (will report if missing)
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/diagnose-deployment (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-71

### Report Issue · Power Pages (`report-issue`)

- **What it does:** Draft a bug report for a Power Pages skill.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Pages
- **Personas:** Developer or maker
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use report-issue: Draft a bug report for a Power Pages skill."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/report-issue (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-248

### Telemetry · Power Pages (`telemetry`)

- **What it does:** Enable, disable or check the power-pages plugin's usage telemetry.
- **Purpose:** Operate | **Tier:** skill | **Products:** Power Pages
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use telemetry: Enable, disable or check the power-pages plugin's usage telemetry."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/telemetry (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-249

### HAR-assisted analysis (`HAR-assisted analysis`)

- **What it does:** Map network bottlenecks to site code and components.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overpage@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overpage: Map network bottlenecks to site code and components."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overpage/skills/powercat-overpage (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-70

### PowerCAT OverPage (`PowerCAT OverPage`)

- **What it does:** Six-pillar review: security, performance, accessibility, maintainability, architecture, and reliability.
- **Purpose:** Review | **Tier:** skill | **Products:** Cross-Cutting, Power Pages, Power CAT, Modernization
- **Personas:** QA lead, Architect, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power CAT Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install powercat-overpage@power-cat-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use powercat-overpage: Six-pillar review: security, performance, accessibility, maintainability, architecture, and reliability."
- **Source:** https://github.com/microsoft/power-cat-skills/tree/main/plugins/powercat-overpage/skills/powercat-overpage (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-12

### Analyze Performance (`analyze-performance`)

- **What it does:** Scan a non-SPA Power Pages site for performance anti-patterns and offer safe fixes with approval.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use analyze-performance: Scan a non-SPA Power Pages site for performance anti-patterns and offer safe fixes with approval."
- **Prerequisite:** An existing local non-SPA Power Pages project or PAC CLI site download.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/analyze-performance (verified 26 Oct 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-158

### Audit Permissions (`audit-permissions`)

- **What it does:** Review table permissions and scopes.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages, Governance
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use audit-permissions: Review table permissions and scopes."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/audit-permissions (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-74

### Compare Site Configurations (`compare-site-configurations`)

- **What it does:** Compare two Power Pages sites' configurations and explain behavior-changing differences.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use compare-site-configurations: Compare two Power Pages sites' configurations and explain behavior-changing differences."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/compare-site-configurations (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-163

### Exceptional Web Design (`exceptional-web-design`)

- **What it does:** Review a site's design and recommend what to change.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages
- **Personas:** QA lead, Architect
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use exceptional-web-design: Review a site's design and recommend what to change."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/exceptional-web-design (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-237

### Migrate WebAPI SelectAll (`migrate-webapi-selectall`)

- **What it does:** Replace deprecated Web API wildcard fields with least-privilege explicit columns.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** None verified. Do not invent one; send the user to the source.
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/migrate-webapi-selectall (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-75

### Scan Code (`scan-code`)

- **What it does:** Inspect frontend code for issues before release.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use scan-code: Inspect frontend code for issues before release."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/scan-code (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-69

### Scan Site (`scan-site`)

- **What it does:** Run a security scan on a deployed site and summarize the findings.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use scan-site: Run a security scan on a deployed site and summarize the findings."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/scan-site (verified 16 Nov 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-241

### Security Review (`security-review`)

- **What it does:** Run a security-focused site assessment.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages, Governance
- **Personas:** QA lead, Admin
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use security-review: Run a security-focused site assessment."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/security-review (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-79

### Test Site (`test-site`)

- **What it does:** Crawl pages in a real browser and inspect console/network failures.
- **Purpose:** Review | **Tier:** skill | **Products:** Power Pages, Governance, Modernization
- **Personas:** QA lead
- **Status:** Generally available (GA) | **Publisher:** Microsoft | **Licence:** MIT licensed
- **Marketplace:** Power Platform Skills
- **Where it runs:** Agent Skill: runs in a coding-agent host that has the plugin installed (for example GitHub Copilot CLI). This Cowork plugin recommends it; it does not run it.
- **Install (verbatim from source):** `/plugin install power-pages@power-platform-skills` (Then start a new session so the skill is discovered.)
- **Example prompt:** "Use test-site: Crawl pages in a real browser and inspect console/network failures."
- **Source:** https://github.com/microsoft/power-platform-skills/tree/main/plugins/power-pages/skills/test-site (verified 7 Sep 2026)
- **Portal page:** https://microsoft.github.io/power-cat-skills/skill-advisor/#skill--skill-68
