# Marketplaces and sources

Catalog refreshed on 17 Nov 2026. Source: Power Platform Skills Advisor portal (https://microsoft.github.io/power-cat-skills/skill-advisor/).

| Marketplace | Items | Publisher(s) | Licence(s) |
|---|---|---|---|
| Power Platform Skills | 165 | Microsoft | MIT licensed |
| Power CAT Skills | 28 | Microsoft | MIT licensed |
| Copilot Studio Plugin | 15 | Microsoft | MIT licensed |
| Dataverse Skills | 14 | Microsoft | MIT licensed |
| Power Apps Mobile Extension | 12 | Microsoft | MIT licensed |
| Agent Skills | 2 | Agent Skills (open standard), Microsoft | MIT licensed, Open standard — see source |
| Model Context Protocol | 1 | Model Context Protocol | Open protocol — see source |
| Microsoft Learn | 1 | Microsoft | Microsoft Learn (CC BY 4.0) |
| Skill Recorder | 1 | Microsoft | MIT licensed |

For full setup of all marketplaces, send the user to the portal Setup page: https://microsoft.github.io/power-cat-skills/skill-advisor/#setup
